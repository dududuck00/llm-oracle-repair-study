"""Final-protocol publication tables. Standard library; no inference or retries.

HumanEval uses final-protocol164-task judgments plus a40-task source validation. Historical compact-interface responses do not
select its common-availability cohort. Historical table generation
remains separate and unchanged.
"""
import hashlib
import json
from pathlib import Path
from judge_repair_analysis import block

ROOT = Path(__file__).resolve().parents[4]
BUILD = ROOT / 'ccfa-workfiles/manuscript/icse-oracle/build'
OUT = ROOT / 'manuscript/publication_tables'
CELLS = [('qwen', m) for m in ['qwen9', 'qwen27', 'qwen35', 'gemma', 'deepseek']] + [('gemma', m) for m in ['qwen9', 'gemma']]
NAMES = dict(qwen='Qwen9B', qwen9='Qwen9B', qwen27='Qwen27B', qwen35='Qwen35B', gemma='Gemma', deepseek='DeepSeek')

def read(p):
    return json.loads((ROOT / p).read_text())

def num(x):
    return f'{x:.2f}'

def signed(x):
    return f'{x:+.2f}'

def slash(xs):
    return '/'.join(str(x) for x in xs)

def table(name, caption, label, header, rows, spec=None, wide=True):
    env = 'table*' if wide else 'table'
    text = [f'\\begin{{{env}}}[t]', r'\centering', r'\small', f'\\caption{{{caption}}}', f'\\label{{{label}}}',
            f'\\begin{{tabular}}{{{spec or "ll" + "r" * (len(header)-2)}}}', r'\toprule', ' & '.join(header) + r' \\', r'\midrule']
    text += [' & '.join(map(str, row)) + r' \\' for row in rows]
    text += [r'\bottomrule', r'\end{tabular}', f'\\end{{{env}}}', '']
    (OUT / f'{name}.tex').write_text('\n'.join(text))

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    BUILD.mkdir(parents=True, exist_ok=True)
    path = 'a7_cross_source/judge_repair/publication/data.json'
    raw = read(path)
    assert len(raw['selected_task_ids']) == 40
    full_path = 'a8_humaneval_full_final_gpu0_v3/publication/data.json'
    extension = read(full_path)
    assert len(extension['tasks']) == 164 and len(extension['reused_tasks']) == 40
    legacy = read('ccfa-workfiles/manuscript/icse-oracle/build/table_evidence.json')
    evidence = {}
    result = dict(humaneval_tasks=164, source_validation_tasks=40, mbppplus_tasks=378, cells={},
                  formal_requests=36336, logical_source_judge_requests=38826, shared_requests=2490,
                  new_formal_requests=26700, reused_qwen_source_requests=8670,
                  availability_uses_final_configuration_only=True, model_calls=0, confidence_intervals=False)
    visibility, guards, decomposition, formation, available = [], [], [], [], []
    for source, judge in CELLS:
        key = source + '/' + judge
        rows = extension['evaluations'][judge] if source == 'qwen' else raw['evaluations'][key]['new']
        task_ids = extension['tasks'] if source == 'qwen' else raw['selected_task_ids']
        assert len(rows) == len(task_ids) * 8 * 6
        assert set(r['task_id'] for r in rows) == set(task_ids)
        groups = {
            'conflicts': [r for r in rows if r['any_conflict'] and r['reference_adjudicable']],
            'guards': [r for r in rows if r['subgroup'] == 'guard' and r['reference_adjudicable']],
            'formed': [r for r in rows if r['original_wellformed'] and r['reference_adjudicable']],
            'full': rows,
        }
        rs = groups['guards']
        bad = {(r['case_id'], r['seed']) for r in rs if r['technical_failure'] or r['dependent_not_started']}
        groups['available_guards'] = [r for r in rs if (r['case_id'], r['seed']) not in bad]
        b = {k: block(v) for k, v in groups.items()}
        result['cells'][key] = b
        c, g, a = [b[x] for x in ['conflicts', 'guards', 'available_guards']]
        assert all(n < 0 for n in g['seed_delta_u']) and a['delta_pp'] < 0
        visibility.append([NAMES[source], NAMES[judge], int(c['n']),
                           num(c['means']['visible']['correct_retained']) + '/' + num(c['means']['hidden']['correct_retained']), signed(c['delta_pp']),
                           int(g['n']), num(g['means']['visible']['correct_retained']) + '/' + num(g['means']['hidden']['correct_retained']), signed(g['delta_pp']), signed(a['delta_pp'])])
        d = g['delta']
        guards.append([NAMES[source], NAMES[judge]] + [signed(d[f]) for f in ['recovered', 'regressed', 'correct_removed_technical', 'correct_removed_defer', 'correct_retained']])
        for name, label in [('conflicts', 'Conflict'), ('guards', 'Guard')]:
            z = b[name]; d = z['delta']; td = z['task_direction']
            decomposition.append([NAMES[source], NAMES[judge], label] + [signed(d[f]) for f in ['recovered', 'regressed', 'correct_removed_technical', 'correct_removed_defer']] + [slash(z['seed_delta_u']), slash(td[f] for f in ['improved', 'worsened', 'tied'])])
        f, full = b['formed'], b['full']
        formation.append([NAMES[source], NAMES[judge], int(f['n']),
                          num(f['means']['visible']['correct_retained']) + '/' + num(f['means']['hidden']['correct_retained']),
                          num(full['means']['visible']['correct_retained']) + '/' + num(full['means']['hidden']['correct_retained']),
                          slash(round(full['means'][arm]['technical_failure'] * 3) for arm in ['visible', 'hidden']),
                          num(full['means']['visible']['new_correct_from_unformed_original']) + '/' + num(full['means']['hidden']['new_correct_from_unformed_original'])])
        available.append([NAMES[source], NAMES[judge], len(groups['available_guards']) // 2,
                          round(a['means']['visible']['correct_retained'] * 3), round(a['means']['hidden']['correct_retained'] * 3), signed(a['delta_pp'])])

    def emit(name, caption, label, header, rows, source, **kw):
        table(name, caption, label, header, rows, **kw)
        evidence[name] = dict(source=source, rows=rows, label=label)

    emit('visibility', r'HumanEval: all 164 tasks for Qwen originals; 40 tasks for Gemma-source validation. Eight inputs and three seeds. $U_V/U_H$ are mean correct-retained counts under visible/hidden originals; $n$ counts frozen inputs. $\Delta$ is hidden minus visible in percentage points. Avail. restricts guards to final-protocol pairs with no technical failure in either arm; its pooled denominators are in the supplement.',
         'tab:visibility', ['Source', 'Judge', '$n_C$', '$U_V/U_H$: conflict', r'$\Delta_C$', '$n_G$', '$U_V/U_H$: guard', r'$\Delta_G$', r'Avail. $\Delta_G$'], visibility, path)
    emit('guard_accounting', r'Guard outcomes: hidden minus visible in mean counts over three seeds. $D_F$ and $D_S$ remove correct originals through technical failure and semantic deferral. Each row obeys $\Delta U=\Delta R-\Delta H-\Delta D_F-\Delta D_S$. Source denominators are 629/217 inputs, with 626/217 correct originals.',
         'tab:guard_accounting', ['Source', 'Judge', r'$\Delta R$', r'$\Delta H$', r'$\Delta D_F$', r'$\Delta D_S$', r'$\Delta U$'], guards, path)
    emit('visibility_decomposition', r'Final-protocol HumanEval outcomes, hidden minus visible in mean counts. Seed differences give $\Delta U$ for 47001/47002/47003. Task directions sum paired inputs and seeds within each active task. Conflict/guard input denominators are 262/629 for Qwen originals and 46/217 for Gemma originals.',
         'tab:s_decomposition', ['Source', 'Judge', 'Group', r'$\Delta R$', r'$\Delta H$', r'$\Delta D_F$', r'$\Delta D_S$', r'Seed $\Delta U$', 'Tasks +/--/='], decomposition, path, spec='lllrrrrrr')
    emit('visibility_formation', r'HumanEval full-frame accounting. Qwen/Gemma sources have 1,312/320 slots. Formed is the reference-adjudicable executable-original cohort. $U$ and newly correct outputs $N$ are means, visible/hidden. $F$ counts logical-cell technical failures summed over three seeds; shared responses remain shared. Missing-original dependencies are 133/32 slots for Qwen/Gemma and remain unstarted.',
         'tab:s_formation', ['Source', 'Judge', 'Formed $n$', 'Formed $U_V/U_H$', 'Full $U_V/U_H$', '$F_V/F_H$', '$N_V/N_H$'], formation, path)
    emit('visibility_availability', r'Guards with technically available responses in both final-protocol arms. $n$ counts pooled input--seed pairs; $U$ is pooled correct retention. Semantic deferral remains eligible. These outcome-conditioned subsets supplement the full-attempt contrast and do not estimate the causal contribution of technical failure.',
         'tab:s_availability', ['Source', 'Judge', 'Pairs $n$', '$U_V$', '$U_H$', r'$\Delta$ pp'], available, path)
    split_rows = []
    split_results = {}
    reused = set(extension['reused_tasks'])
    for judge in ['qwen9', 'qwen27', 'qwen35', 'gemma', 'deepseek']:
        rows = extension['evaluations'][judge]
        split_results[judge] = {}
        row = [NAMES[judge]]
        for group in ['conflicts', 'guards']:
            for scope, selected in [('reused40', reused), ('new124', set(extension['tasks']) - reused), ('full164', set(extension['tasks']))]:
                rs = [r for r in rows if r['task_id'] in selected and r['reference_adjudicable'] and
                      (r['any_conflict'] if group == 'conflicts' else r['subgroup'] == 'guard')]
                b = block(rs)
                split_results[judge][scope + '/' + group] = b
                row.append(signed(b['delta_pp']))
        split_rows.append(row)
    result['task_splits'] = split_results
    result['full164_negative_guard_seed_comparisons'] = sum(n < 0 for j in split_results.values() for n in j['full164/guards']['seed_delta_u'])
    result['new124_negative_guard_seed_comparisons'] = sum(n < 0 for j in split_results.values() for n in j['new124/guards']['seed_delta_u'])
    assert result['full164_negative_guard_seed_comparisons'] == result['new124_negative_guard_seed_comparisons'] == 15
    emit('visibility_task_splits', r'Qwen-source visibility effects in the reused 40-task subset, added 124 tasks and complete 164-task frame. Entries are hidden minus visible correct retention, percentage points. Conflict denominators are 63/199/262 and guard denominators 169/460/629. The 40- and 124-task subsets partition the full cohort; they are not independent datasets.',
         'tab:s_task_splits', ['Judge', 'Conflict 40', 'Conflict 124', 'Conflict 164', 'Guard 40', 'Guard 124', 'Guard 164'], split_rows, full_path, spec='lrrrrrr')

    type_rows = legacy['five_model_types']['rows']
    emit('types', r'MBPP+: all 378 tasks, four input slots per task and three seeds. $U$ is mean correct retention out of 1,512 slots. DR/TR: direct/derivation with raw output; DT/TT: direct/derivation with automatic types. Known counts usable task types; $\Delta_T$ is TT--TR in percentage points. DeepSeek falls back on every task, so its typed/raw responses are identical.',
         'tab:types_full', ['Checkpoint', 'Known/378', '$U_{DR}$', '$U_{TR}$', '$U_{DT}$', '$U_{TT}$', r'$\Delta_T$', 'Tasks +/--/='], type_rows, legacy['five_model_types']['source'], spec='lrrrrrrr')
    action_rows = legacy['five_model_actions']['rows']
    emit('actions', r'Common finite-contract panel: 192 valid responses per checkpoint, 96 correct originals and 48 repairable cases. $E$ counts rule violations; $E_c/C$ conditions on correct requirement status and both assertion labels. Arrows show direct to rule-bound outcomes. Protection K/D splits prevented harms into KEEP/DEFER; lost/gained gives recovery turnover.',
         'tab:actions_full', ['Checkpoint', '$E$', '$E_c/C$', '$H$', '$R$', '$U$', 'Protection K/D', 'Lost/gained'], action_rows, legacy['five_model_actions']['source'], spec='lrrrrrrr')

    supply = legacy['supply']['rows']
    control_rows = [[row[0]] + [row[i] for i in [1, 2, 3, 4, 6]] for row in supply]
    emit('controls', r'Candidate supply on 24 new templates, two seeds: 480 specified conflicts per seed, 120 correct originals and 360 wrong originals. Reused values share the base inference; extra sampling consumes the recorded budget. Means are per seed; tokens are logical consumption per panel.',
         'tab:controls', ['Candidate pool', '$U/480$', '$R/360$', '$H/120$', '$D/120$', 'Tokens/panel'], control_rows, legacy['supply']['source'], spec='lrrrrr')
    emit('type_diagnostics', r'MBPP+ type effect (TT--TR), percentage points. Conditional subsets use usable predictions, compatibility with observed reference types, or valid responses in all four conditions. Common validity retains semantic deferral; $n$ counts input--seed pairs. Empty subsets are N/A. Observed compatibility is not an independent requirement annotation.',
         'tab:s_type_diagnostics', ['Checkpoint', 'Known', 'All', 'Known subset', 'Compatible', 'Common valid', '$n$'], legacy['five_model_type_diagnostics']['rows'], legacy['five_model_type_diagnostics']['source'], spec='lrrrrrr')
    emit('action_strata', r'DeepSeek action errors by finite family and seed. $C$ has correct decision fields, $E_c$ violates the rule within $C$, and $H_c$ is harmful repair within $C$. Family rows and seed rows partition the same 192 responses. The eight $H_c$ events span five families and two seeds; one is a conflict and seven are guards.',
         'tab:s_action_strata', ['Family or seed', '$n$', '$C$', '$E$', '$E_c$', '$H_c$'], legacy['deepseek_action_strata']['rows'], legacy['deepseek_action_strata']['source'], spec='lrrrrr')

    settings = r'''\begin{table}[t]
\centering\small
\caption{Evidence and controls. Natural outcomes use executable references; finite controls use authored legal-result relations.}
\label{tab:settings}
\begin{tabularx}{\columnwidth}{@{}lX@{}}
\toprule
Study & Materials and paired comparison \\
\midrule
RQ1 & 164 HumanEval tasks, 8 inputs, 3 seeds, 5 judges; 40-task Gemma-source validation with 2 judges; original visible/hidden. \\
RQ2 & 378 MBPP+ tasks, 4 inputs, 3 seeds, 5 checkpoints; direct/derivation $\times$ raw/automatic type. Same-response value mapping on 24 finite templates. \\
RQ3 & 24-template candidate-supply controls; shared proposals and retention-matched review masks. \\
RQ4 & 12 finite families, 2 inputs, 2 seeds; 192 panels per checkpoint; direct/rule-bound action on identical fields. \\
\bottomrule
\end{tabularx}
\end{table}
'''
    (OUT / 'settings.tex').write_text(settings)
    result['guard_negative_cell_seed_comparisons'] = sum(n < 0 for c in result['cells'].values() for n in c['guards']['seed_delta_u'])
    result['available_guard_negative_cells'] = sum(c['available_guards']['delta_pp'] < 0 for c in result['cells'].values())
    assert result['guard_negative_cell_seed_comparisons'] == 21 and result['available_guard_negative_cells'] == 7
    result['source_sha256'] = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in [path, full_path, 'ccfa-workfiles/manuscript/icse-oracle/build/table_evidence.json']}
    (BUILD / 'icpc_results.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
    (BUILD / 'icpc_table_evidence.json').write_text(json.dumps(evidence, indent=2, ensure_ascii=False) + '\n')
    return result

if __name__ == '__main__':
    result = main()
    print(json.dumps(dict(passed=True, main_numerical_tables=5, supporting_numerical_tables=6, model_calls=0,
                          negative_guard_seed_comparisons=result['guard_negative_cell_seed_comparisons'])))
