"""Render manuscript tables from the existing, unchanged experiment summaries."""
import json
import random
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
PILOT = ROOT.parent / "oracle-conflict-pilot-20261005"
OUT = ROOT / "manuscript" / "tables"
OUT.mkdir(parents=True, exist_ok=True)
evidence = {}


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def num(value):
    return f"{value:.2f}"


def table(name, caption, label, header, rows, wide=False, spec=None):
    env = "table*" if wide else "table"
    spec = spec or "l" + "r" * (len(header) - 1)
    text = [f"\\begin{{{env}}}[t]", "\\centering", "\\small",
            f"\\caption{{{caption}}}", f"\\label{{{label}}}",
            f"\\begin{{tabular}}{{{spec}}}", "\\toprule",
            " & ".join(header) + r" \\", "\\midrule"]
    text += [" & ".join(str(x) for x in row) + r" \\" for row in rows]
    text += ["\\bottomrule", "\\end{tabular}", f"\\end{{{env}}}", ""]
    (OUT / f"{name}.tex").write_text("\n".join(text), encoding="utf-8")


p3 = read(PILOT / "phase3/runs/summary.json")
a = p3["analyses"]["anchor_primary"]["mean_over_seeds"]
rows = []
for key, title in [("A_PRESERVE", "Visible, preserve if correct"),
                   ("B_VISIBLE", "Visible, derive independently"),
                   ("C_HIDDEN", "Hidden, derive independently")]:
    m = a[key]
    rows.append([title] + [num(m[k]) for k in ["recovered", "regressed", "correct_retained"]])
evidence["anchoring"] = {"source": "../oracle-conflict-pilot-20261005/phase3/runs/summary.json", "rows": rows,
                         "counterfactual": p3["counterfactual_effective"]}
table("anchoring", "Original-assertion visibility on 150 natural conflict events. Counts are means over three seeds. All conditions hide the auxiliary implementation and its execution.",
      "tab:anchoring", ["Generation condition", "$R$", "$H$", "$U$"], rows)

p4 = read(PILOT / "phase4/runs/summary.json")
rows = []
for key, title in [("FULL", "Full view"), ("MASK", "Isolated views"),
                   ("TARGET", "Target binding"), ("BOUND", "Evidence binding"),
                   ("BOUND_QUOTE", "Quote filter"), ("REVIEW", "General review"),
                   ("CHECK", "Consistency review")]:
    m = p4["analyses"]["primary"]["mean_over_seeds"][key + "_GATED"]
    assert abs(m["correct_retained"] - (m["initial_correct"] + m["recovered"] - m["regressed"] - m["removed_correct"])) < 1e-8
    rows.append([title] + [num(m[k]) for k in ["recovered", "regressed", "removed_correct", "correct_retained", "retained"]])
evidence["attribution"] = {"source": "../oracle-conflict-pilot-20261005/phase4/runs/summary.json", "rows": rows}
table("attribution", "Attribution interventions with the same repair candidates and routing rule on 150 events, initially 14 reference-consistent. Means over three seeds. $D$ counts deferred correct assertions; $K$ counts all retained assertions.",
      "tab:attribution", ["Judgment condition", "$R$", "$H$", "$D$", "$U$", "$K$"], rows)

p9 = read(PILOT / "phase9/runs/summary.json")
p10 = read(PILOT / "phase10/runs/summary.json")
rows = []
for key, title in [("DIRECT_RAW", "Direct, unconstrained"), ("DIRECT_TYPED", "Direct, typed"),
                   ("TRACE_RAW", "Derivation, unconstrained"), ("TRACE_TYPED", "Derivation, typed")]:
    m = p9["analyses"]["all"]["means"][key]
    rows.append(["Type factorial", title, num(m["correct_retained"]), num(m["type_violations"]), num(m["charged_tokens"] / m["n"])])
for key, title in [("TRACE_RAW", "Derivation, unconstrained"), ("TRACE_FIXED", "Derivation, typed")]:
    m = p10["natural"]["means"][key]
    rows.append(["New-task replication", title, num(m["correct_retained"]), num(m["type_violations"]), num(m["charged_tokens"] / m["n"])])
evidence["types"] = {"sources": ["../oracle-conflict-pilot-20261005/phase9/runs/summary.json", "../oracle-conflict-pilot-20261005/phase10/runs/summary.json"], "rows": rows}
table("types", "Type constraints and explicit derivation on two separate 40-task MBPP cohorts, each with 320 inputs and three seeds. $U$ is reference-consistent retained assertions out of 320. Type violations and total model tokens per input are reported separately.",
      "tab:types", ["Cohort", "Generation condition", "$U/320$", "Type violations", "Tokens/input"], rows, wide=True, spec="llrrr")

p35 = read(ROOT / "phase35/summary.json")
rows = []
for key, title in [("TRACE_ID", "Model IDs"), ("TRACE_VALUES", "Mapped values")]:
    m = p35["main"]["means"][key]
    rows.append([title] + [num(m[k]) for k in ["useful", "recovery", "regression", "correct_discard", "retained"]])
evidence["mapping"] = {"source": "phase35/summary.json", "rows": rows}
table("mapping", "A paired encoding intervention on the same model responses. Known conflicts: 96; initially correct: 24; initially wrong: 72. A further 24 unspecified events remain in the submission denominator of 120. No additional model calls are used.",
      "tab:mapping", ["Encoding", "$U$", "$R$", "$H$", "$D$", "$K$"], rows)

p32 = read(ROOT / "phase32/runs/summary.json")
rows = []
for key, title in [("WHOLE_TEXT", "Whole assertion, text"), ("WHOLE_WITNESS", "Whole assertion, witness"),
                   ("DELTA_TEXT", "Acceptance difference, text"), ("DELTA_WITNESS", "Acceptance difference, witness")]:
    m = p32["main_conflict"]["means"][key]
    rows.append([title] + [num(m[k]) for k in ["useful", "recovery", "regression", "correct_discard", "retained", "unknown_submit"]])
evidence["difference"] = {"source": "phase32/runs/summary.json", "rows": rows}
table("difference", "Whole-assertion and acceptance-difference review with text or executable witnesses. Means over three seeds on 240 configurations from 24 templates. Known conflicts: 960; initially correct: 240; initially wrong: 720; unspecified: 240. $K$ includes all submitted conflict assertions.",
      "tab:difference", ["Review condition", "$U/960$", "$R/720$", "$H/240$", "$D/240$", "$K/1200$", "$S/240$"], rows, wide=True)

p37 = read(ROOT / "phase37/summary.json")
rows = []
for key, title in [("BASE", "Fixed candidate pool"), ("LITERAL_SUPPLY", "Reuse generated values"), ("NATIVE_BUDGET", "Budgeted extra sampling")]:
    m = p37["main"]["means"][key]
    kept = m["original_correct"] - m["regression"] - m["correct_discard"]
    assert abs(m["useful"] - kept - m["recovery"]) < 1e-8
    rows.append([title] + [num(m[k]) for k in ["useful", "recovery", "regression", "correct_discard"]] + [num(kept), num(p37["costs"][key]["logical_tokens_per_panel"])])
evidence["supply"] = {"source": "phase37/summary.json", "rows": rows}
table("supply", "Candidate supply on 120 configurations from 24 new templates. Means over two seeds. Known conflicts: 480; initially correct: 120; initially wrong: 360. All three conditions defer the 120 unspecified conflict events. Tokens include the calls required by each route, averaged over all panels.",
      "tab:supply", ["Candidate condition", "$U/480$", "$R/360$", "$H/120$", "$D/120$", "Correct kept/120", "Tokens/panel"], rows, wide=True)

p45 = read(ROOT / "phase45/summary.json")
rows = []
for arm in ["G_N", "G_E", "L_N", "L_E"]:
    raw = p45["arms"][arm]["raw"]["all"]
    bound = p45["arms"][arm]["bound"]["all"]
    vals = []
    for k in ["useful", "regression", "correct_discard", "unknown_submit"]:
        vals += [str(raw[k]), str(bound[k])]
    rows.append([arm.replace("_", r"\_")] + vals)
    for m in [raw, bound]:
        assert m["useful"] == m["original_correct"] + m["recovery"] - m["regression"] - m["correct_discard"]
evidence["action_binding"] = {"source": "phase45/summary.json", "rows": rows}
table("action_binding", "Direct model actions and the original status-first policy $\\pi_S$ from the same judgment response. Adjacent columns report direct and bound actions for each metric. Counts sum two seeds: 576 specified cases, 192 initially correct, 384 initially wrong, and 288 unspecified cases. G/L denotes global-program/current-assertion attention; N/E denotes ordinary/expanded semantic instructions.",
      "tab:action", ["Condition", "$U$ direct", "$U$ bound", "$H$ direct", "$H$ bound", "$D$ direct", "$D$ bound", "$S$ direct", "$S$ bound"], rows, wide=True)

rows = []
for arm in ["G_N", "G_E", "L_N", "L_E"]:
    m = p45["arms"][arm]["gated"]["all"]
    r = p45["arms"][arm]["random"]["keep_repair_matched"]
    # Random summaries are nested in the frozen file; keep their exact structure in provenance.
    rows.append([arm.replace("_", r"\_")] + [str(m[k]) for k in ["useful", "recovery", "regression", "correct_discard", "unknown_submit", "submitted"]])
evidence["fixed_proposal"] = {"source": "phase45/summary.json", "rows": rows}
table("fixed_proposal", "Submitting or deferring an identical fixed proposal in the assertion counterfactual study. Denominators are the same as Table~\\ref{tab:action}; $K$ is out of 864. These decisions leave the proposal unchanged.",
      "tab:fixed", ["Condition", "$U$", "$R$", "$H$", "$D$", "$S$", "$K$"], rows)


def arrow(left, right):
    return f"${left}\\to {right}$"


p0 = read(ROOT / "phase45/p0_action_binding/summary.json")
rows = []
for scope, title in [("specified", "All specified"), ("specified_conflict", "Conflicts"), ("specified_guard", "Guards")]:
    m = p0["descriptive_pooled"][scope]
    raw, bound, d = m["policies"]["raw"], m["policies"]["bound"], m["decomposition"]
    assert raw["regression"] - bound["regression"] == d["harm_prevented_to_keep"] + d["harm_prevented_to_defer"] - d["harm_introduced"]
    assert bound["recovery"] - raw["recovery"] == d["recovery_gained"] - d["recovery_lost"]
    rows.append([title, "All conditions", arrow(raw["regression"], bound["regression"]), d["harm_prevented_to_keep"], d["harm_prevented_to_defer"], arrow(raw["recovery"], bound["recovery"]), d["recovery_lost"], d["recovery_gained"]])
for arm in ["G_N", "G_E", "L_N", "L_E"]:
    m = p0["arms"][arm]["specified_conflict"]
    raw, bound, d = m["policies"]["raw"], m["policies"]["bound"], m["decomposition"]
    assert bound["recovery"] - raw["recovery"] == d["recovery_gained"] - d["recovery_lost"]
    rows.append(["Conflicts", arm.replace("_", r"\_"), arrow(raw["regression"], bound["regression"]), d["harm_prevented_to_keep"], d["harm_prevented_to_defer"], arrow(raw["recovery"], bound["recovery"]), d["recovery_lost"], d["recovery_gained"]])
evidence["action_paths"] = {"source": "phase45/p0_action_binding/summary.json", "policy": "original status-first pi_S", "rows": rows, "scope_audit": read(ROOT / "phase45/p0_action_binding/policy_scope_audit.json")}
table("action_paths", "Protection and recovery under the original status-first action policy. Harm and recovery cells show direct $\\to$ bound counts; protected harms are split by their destination. The all-condition rows sum responses to the same panels under four conditions, rather than independent tasks. Per condition there are 576 specified panels: 384 conflicts and 192 guards.",
      "tab:action_paths", ["Scope", "Condition", "$H$ direct$\\to$bound", "To KEEP", "To DEFER", "$R$ direct$\\to$bound", "Lost $R$", "Gained $R$"], rows, wide=True)

a1 = read(ROOT / "a1_reason_limit/summary.json")
rows = []
for arm in ["G_CAP240", "G_NOCHAR", "L_CAP240", "L_NOCHAR"]:
    m = a1["arms"][arm]["all"]
    d, raw = m["diagnostics"], m["policies"]["raw"]
    assert raw["useful"] == raw["original_correct"] + raw["recovery"] - raw["regression"] - raw["correct_discard"]
    rows.append([arm[0], "240" if arm.endswith("CAP240") else "None", f'{d["valid"]}/192', d["literal_rule_mismatch"], d["supported_original_but_raw_repair"], raw["recovery"], raw["regression"], raw["correct_discard"], raw["useful"]])
evidence["reason_limit"] = {"source": "a1_reason_limit/summary.json", "rows": rows, "paired": a1["paired"], "cost": a1["cost"], "error_layers": read(ROOT / "a1_reason_limit/posthoc_error_layers.json")}
table("reason_limit", "Reason-character limit at a common 1,024-token output cap. Each arm has 192 attempts over the same 96 base configurations and two seeds; 96 originals are correct and 48 have a correct replacement. Policy violations refer to the literal three-branch action sentence and are counted on valid responses. All 13 unavailable responses exhaust the token cap in the uncapped arms and remain in the outcome denominators.",
      "tab:reason_limit", ["Focus", "Char. bound", "Valid", "Policy violations", "Supported$\\to$REPAIR", "$R$", "$H$", "$D$", "$U$"], rows, wide=True)

rows = []
for scope, title in [("all", "All specified"), ("conflict", "Conflicts")]:
    for arm in ["G_NOCHAR", "L_NOCHAR"]:
        m = a1["arms"][arm][scope]
        raw, bound = m["policies"]["raw"], m["policies"]["literal"]
        d = m["binding"]["literal"]["counts"]
        assert bound["recovery"] - raw["recovery"] == d["recovery_gained"] - d["recovery_lost"]
        rows.append([title, arm[0], arrow(raw["regression"], bound["regression"]), d["harm_prevented_to_keep"], d["harm_prevented_to_defer"], arrow(raw["recovery"], bound["recovery"]), d["recovery_lost"], d["recovery_gained"]])
evidence["reason_binding"] = {"source": "a1_reason_limit/summary.json", "policy": "prompt literal pi_L", "rows": rows}
table("reason_binding", "Same-response action binding after removal of the reason-character limit. The bound action follows the prompt's literal policy $\\pi_L$, without the additional status-first gate. All-attempt outcome counts include technical deferrals. Protection and recovery turnover are reported separately for all specified panels and actual execution conflicts.",
      "tab:reason_binding", ["Scope", "Focus", "$H$ direct$\\to$bound", "To KEEP", "To DEFER", "$R$ direct$\\to$bound", "Lost $R$", "Gained $R$"], rows, wide=True)


a2 = read(ROOT / "a2_cross_model/summary.json")
assert a2["execution"]["complete"]
rows = []
for model, title in [("qwen35_9b", "Qwen"), ("llama31_8b", "Llama")]:
    d = a2["models"][model]["all"]["diagnostics"]
    rows.append([title, f'{d["valid"]}/{d["attempts"]}', f'{d["decision_fields_correct"]}/{d["valid"]}', f'{d["rule_mismatch"]}/{d["valid"]}', f'{d["rule_mismatch_when_decision_fields_correct"]}/{d["decision_fields_correct"]}', f'{d["legal_singleton_false_support"]}/{d["legal_singleton_targets_available"]}'])
evidence["cross_model_layers"] = {"source": "a2_cross_model/summary.json", "rows": rows, "paired": a2["paired"], "cost": a2["cost"]}
table("cross_model_layers", "Technical availability, decision fields, and action consistency on the common 12-family panel. Qwen is Qwen3.5-9B; Llama is Llama-3.1-8B-Instruct. Correct decision fields comprise requirement status and both assertion labels, excluding global-program validity, which the action rule does not use. False singleton support is measured over available eligible assertion targets, not tasks. All six unavailable responses are Llama token-limit failures.",
      "tab:cross_layers", ["Model", "Valid/attempted", r"\shortstack{Decision fields\\correct/valid}", r"\shortstack{Rule errors\\/valid}", r"\shortstack{Rule errors/\\correct fields}", r"\shortstack{False singleton\\support/targets}"], rows, wide=True)

rows = []
for model, title in [("qwen35_9b", "Qwen"), ("llama31_8b", "Llama")]:
    m = a2["models"][model]["all"]
    d = m["binding"]["bound"]["counts"]
    raw, bound = m["policies"]["raw"], m["policies"]["bound"]
    assert raw["regression"] - bound["regression"] == d["harm_prevented_to_keep"] + d["harm_prevented_to_defer"] - d["harm_introduced"]
    assert bound["recovery"] - raw["recovery"] == d["recovery_gained"] - d["recovery_lost"]
    for policy, policy_title in [("raw", "Direct"), ("bound", "Bound"), ("KEEP", "Always KEEP"), ("DEFER", "Always DEFER")]:
        z=m["policies"][policy]
        assert z["useful"] == z["original_correct"] + z["recovery"] - z["regression"] - z["correct_discard"]
        protect=f'{d["harm_prevented_to_keep"]}/{d["harm_prevented_to_defer"]}' if policy=="bound" else "--"
        turnover=f'{d["recovery_lost"]}/{d["recovery_gained"]}' if policy=="bound" else "--"
        rows.append([title,policy_title,z["recovery"],z["regression"],z["correct_discard"],z["useful"],protect,turnover])
evidence["cross_model_outcomes"] = {"source": "a2_cross_model/summary.json", "policy": "A2 explicit status-first pi_S", "rows": rows}
table("cross_model_outcomes", "Entailment outcomes on all 192 attempted panels per model: 96 supported originals, 96 violated originals, and 48 supported replacement candidates. $U$ counts retained entailed assertions. Bound executes the explicitly prompted status-first policy on the same response. Its prevented harms are split into KEEP/DEFER destinations, and recovery turnover is split into lost/gained repairs relative to Direct. Always-KEEP and Always-DEFER are zero-call controls. Technical failures remain in all-attempt outcomes.",
      "tab:cross_outcomes", ["Model", "Policy", "$R$", "$H$", "$D$", "$U$ entailed", r"\shortstack{Protected harms\\KEEP/DEFER}", r"\shortstack{Recovery\\lost/gained}"], rows, wide=True)

# This appendix supplements the registered all-attempt endpoints with a
# descriptive breakdown. Its input is rebuilt from immutable A2 evaluations.
from review_sensitivity import main as build_review_sensitivity

build_review_sensitivity()
review_path = ROOT / "ccfa-workfiles/manuscript/icse-oracle/build/review_sensitivity.json"
review = read(review_path)
assert review["passed"]
family_titles = {
    "adjacent_absolute_difference_total": "Adjacent gap total",
    "strict_inversion_count": "Inversion count",
    "strict_interior_peak_count": "Interior peaks",
    "first_repeated_entry_index": "First repeated index",
    "longest_nondecreasing_contiguous_run": "Longest nondecreasing run",
    "nonzero_sign_change_count": "Nonzero sign changes",
    "any_most_frequent_value": "Any mode",
    "any_least_frequent_present_value": "Least frequent value",
    "any_nearest_to_zero_value": "Nearest zero",
    "any_adjacent_pair_sum": "Adjacent pair sum",
    "any_nonempty_proper_prefix_sum": "Proper prefix sum",
    "any_positive_pairwise_absolute_difference": "Positive pairwise gap",
}


def strata_cells(count):
    return [f'{count["valid"]}/{count["attempted"]}', count["rule_errors"],
            f'{count["rule_errors_when_decision_fields_correct"]}/{count["decision_fields_correct"]}']


rows = []
for stratum in review["family_seed"]:
    rows.append([family_titles[stratum["family"]], str(stratum["seed"])[-1]] +
                strata_cells(stratum["models"]["qwen35_9b"]) +
                strata_cells(stratum["models"]["llama31_8b"]))
for seed in (46001, 46002):
    rows.append(["All families", str(seed)[-1]] +
                strata_cells(review["models"]["qwen35_9b"]["by_seed"][str(seed)]) +
                strata_cells(review["models"]["llama31_8b"]["by_seed"][str(seed)]))
rows.append(["All families", "Both"] + strata_cells(review["models"]["qwen35_9b"]["all"]) +
            strata_cells(review["models"]["llama31_8b"]["all"]))
evidence["cross_model_strata"] = {
    "source": str(review_path.relative_to(ROOT)),
    "analysis_kind": review["analysis_kind"],
    "inputs_sha256": review["inputs_sha256_before"],
    "family_titles": family_titles, "rows": rows,
}
table("cross_model_strata", "Post-hoc descriptive breakdown of the A2 panel by family and seed. Seeds 1 and 2 denote 46001 and 46002. The first six families have unique outputs; the last six permit multiple outputs. For each model, $V/n$ is valid/attempted responses, $E$ counts rule errors among valid responses, and $E_c/C$ counts rule errors among responses with all three correct action-decision fields. Each family--seed stratum contains eight repeated configurations per model. These strata supplement the all-attempt endpoints in Tables~\\ref{tab:cross_layers} and~\\ref{tab:cross_outcomes}.",
      "tab:cross_strata", ["Family", "Seed", "Qwen $V/n$", "$E$", "$E_c/C$", "Llama $V/n$", "$E$", "$E_c/C$"], rows, wide=True, spec="llrrrrrr")

# The A3 table reads unchanged completed-model summaries; the retained Gemma
# engineering failure remains in v2 costs and never enters a formal denominator.
a3q = read(ROOT / "a3_model_extension_v2/summary.json")
a3g = read(ROOT / "a3_gemma_interface_v3/summary.json")
rows = []
for mid, title, summary in [
    ("qwen38_27b", "Qwen3.8-27B", a3q),
    ("qwen35_35b_a3b", "Qwen3.5-35B-A3B", a3q),
    ("gemma4_26b_a4b_it", "Gemma-4-26B-A4B-it", a3g),
]:
    group = summary["models"][mid]["all"]
    diag, policy = group["diagnostics"], group["policies"]
    assert diag["attempts"] == diag["valid"] == 192
    assert policy["raw"]["regression"] == policy["bound"]["regression"] == 0
    assert policy["raw"]["recovery"] == policy["bound"]["recovery"]
    assert group["binding"]["bound"]["counts"]["recovery_lost"] == group["binding"]["bound"]["counts"]["recovery_gained"] == 0
    rows.append([title, "192/192", diag["decision_fields_correct"], diag["rule_mismatch"],
                 f'{diag["rule_mismatch_when_decision_fields_correct"]}/{diag["decision_fields_correct"]}',
                 0, policy["raw"]["recovery"],
                 str(policy["raw"]["correct_discard"]) + r"$\to$" + str(policy["bound"]["correct_discard"]),
                 str(policy["raw"]["useful"]) + r"$\to$" + str(policy["bound"]["useful"])])
evidence["model_extension"] = {"sources": ["a3_model_extension_v2/summary.json", "a3_gemma_interface_v3/summary.json"], "rows": rows,
                              "formal_requests": 576, "all_engineering_requests": 16, "all_requests": 592, "measured_tokens": 561724}
table("model_extension", "Additional checkpoints on the frozen A2 panel. All 192 formal responses per model are valid. $C$ counts responses with all three correct action-decision fields, $E$ rule errors, and $E_c/C$ rule errors within that subset. $H$ and $R$ are identical under direct and bound actions; no recovery is lost or gained. Correct deferral $D$ and useful retention $U$ show direct-to-bound counts. Each model has 96 initially correct and 48 repairable originals. Gemma's three rule errors are unnecessary deferrals, all corrected to KEEP.",
      "tab:model_extension", ["Checkpoint", "$V/n$", "$C$", "$E$", "$E_c/C$", "$H$", "$R$", "$D$: raw $\\to$ bound", "$U$: raw $\\to$ bound"], rows, wide=True, spec="lrrrrrrrr")

# A4 has its own all-task input frame and a conflict subgroup frozen before
# the paired calls.  Never replace a missing completed result with an empty
# table or combine newly run cases with historical Phase3 requests.
a4_root = ROOT / "a4_humaneval_full_v2"
a4_publication = read(a4_root / "publication_results.json")
a4 = a4_publication
a4_verification = read(a4_root / "verification.json")
assert a4["complete"] and a4_verification["passed"]
assert all(a4_verification["checks"].values())
assert a4["cohort"]["tasks"] == 164 and a4["cohort"]["planned_inputs"] == 1312
evaluation_path = a4_root / "evaluations.jsonl"
with evaluation_path.open(encoding="utf-8") as stream:
    a4_evaluations = [json.loads(line) for line in stream if line.strip()]
assert len(a4_evaluations) == 1312 * 3 * 2
assert len({(row["case_id"], row["seed"], row["arm"]) for row in a4_evaluations}) == len(a4_evaluations)


def a4_scope(row, scope):
    if scope == "main_conflicts":
        return row["any_conflict"] and row["reference_adjudicable"]
    if scope == "guards_observed":
        return row["subgroup"] == "guard" and row["reference_adjudicable"]
    assert scope == "all_fixed_slots"
    return True


def a4_point(rows):
    den=sum(r["arm"]=="visible" for r in rows)
    return None if not den else (sum(bool(r["correct_retained"]) for r in rows if r["arm"]=="hidden")-sum(bool(r["correct_retained"]) for r in rows if r["arm"]=="visible"))/den


rows = []
for scope, title in [("main_conflicts", "Execution conflicts"),
                     ("all_fixed_slots", "All fixed input slots"),
                     ("guards_observed", "Observed guards")]:
    group = a4["analyses"][scope]
    scoped = [row for row in a4_evaluations if a4_scope(row, scope)]
    point = a4_point(scoped)
    saved = group["hidden_minus_visible_correct_retained"]
    assert (point is None and saved is None) or abs(point-saved["point"])<1e-12
    for arm, arm_title in [("visible", "Visible"), ("hidden", "Hidden")]:
        m = group["mean_over_seeds"][arm]
        for field in ("n", "initial_correct", "recovered", "regressed", "removed_correct",
                      "correct_retained", "retained", "new_correct_from_unformed_original"):
            values = []
            for seed in a4["seeds"]:
                selected = [row for row in scoped if row["arm"] == arm and row["seed"] == seed]
                values.append(len(selected) if field == "n" else sum(bool(row[field]) for row in selected))
            assert abs(m[field] - statistics.mean(values)) < 1e-8, (scope, arm, field)
        assert abs(m["correct_retained"] - (m["initial_correct"] + m["recovered"] -
                   m["regressed"] - m["removed_correct"] + m["new_correct_from_unformed_original"])) < 1e-8
        rows.append([title, arm_title, num(m["n"]), num(m["initial_correct"])] +
                    [num(m[key]) for key in ("recovered", "regressed", "removed_correct", "correct_retained", "retained")])
contrast = a4["analyses"]["main_conflicts"]["hidden_minus_visible_correct_retained"]
assert contrast and contrast["task_frame"] == 164
full = a4["analyses"]["all_fixed_slots"]["mean_over_seeds"]
caption = (
    "Uniform original-assertion visibility confirmation across all 164 HumanEval tasks, with eight frozen inputs per task. "
    "Counts are means over three paired seeds; $N$ is the number of unique input slots, not candidate-implementation events. "
    "The execution-conflict subgroup is frozen before the paired calls. $C_0$ counts reference-consistent originals. "
    "Hidden minus visible useful retention on conflicts is " + num(100 * contrast["point"]) +
    " percentage points. "
    "All fixed input slots retain missing-original dependencies and reference-unadjudicable cases in the coverage denominator. "
    "Useful retention additionally includes " + num(full["visible"]["new_correct_from_unformed_original"]) +
    "/" + num(full["hidden"]["new_correct_from_unformed_original"]) +
    " newly reference-consistent outputs from unformed originals in visible/hidden. "
    "Observed guards have at least one evaluable candidate and no observed failure; they do not establish global program correctness."
)
evidence["humaneval_coverage"] = {
    "source": "a4_humaneval_full_v2/publication_results.json", "rows": rows,
    "source_sha256": a4_publication["source_sha256"],
    "main_hidden_minus_visible": contrast, "cost": a4["cost"],
}
table("humaneval_coverage", caption, "tab:humaneval_coverage",
      ["Cohort", "Visibility", "$N$", "$C_0$", "$R$", "$H$", "$D$", "$U$", "$K$"],
      rows, wide=True, spec="llrrrrrrr")


# A5 all-task automatic type acquisition and representation confirmation.
a5_root = ROOT / "a5_mbppplus_full"
a5 = read(a5_root / "publication_results.json")
a5_check = read(a5_root / "verification.json")
assert a5["complete"] and a5_check["passed"] and all(a5_check["checks"].values())
assert a5["tasks"] == 378 and a5["input_slots"] == 1512 and a5["distinct_inputs"] == 1511
with (a5_root / "evaluations.jsonl").open() as stream:
    a5_evaluations = [json.loads(line) for line in stream if line.strip()]
assert len(a5_evaluations) == 18144
physical_evaluations = {row["physical_id"]: row for row in a5_evaluations}
assert len(physical_evaluations) == a5["cost"]["physical_generation_calls"] == 17556
a5_error_layers = {
    "physical_response_failures": sum(row["wire_failure"] for row in physical_evaluations.values()),
    "physical_assertion_formation_failures": sum(row["formation_failure"] for row in physical_evaluations.values()),
    "logical_failure_slots": sum(row["technical_failure"] for row in a5_evaluations),
}
assert a5_error_layers["physical_response_failures"] == a5["cost"]["by_stage"]["generate"]["failed_calls"]
assert a5_error_layers["physical_assertion_formation_failures"] == 235
assert a5_error_layers["logical_failure_slots"] == 1152
arms = ["DIRECT_RAW", "TRACE_RAW", "DIRECT_TYPED", "TRACE_TYPED"]
seeds = [52001, 52002, 52003]
task_frame = sorted({row["task_id"] for row in a5_evaluations}, key=lambda name: int(name.split("/")[-1]))
assert len(task_frame) == 378
main_a5 = a5["analyses"]["all_fixed_slots"]
rows = []
for arm, title in [("DIRECT_RAW", "Direct, raw"), ("TRACE_RAW", "Derivation, raw"),
                   ("DIRECT_TYPED", "Direct, automatic type"), ("TRACE_TYPED", "Derivation, automatic type")]:
    m = main_a5["mean_over_seeds"][arm]
    for field in ["n", "initial_correct", "correct_retained", "recovered", "regressed", "removed_correct",
                  "new_correct_from_unformed_original", "technical_failure", "representation_only"]:
        values = []
        for seed in seeds:
            selected = [r for r in a5_evaluations if r["arm"] == arm and r["seed"] == seed]
            values.append(len(selected) if field == "n" else sum(bool(r[field]) for r in selected))
        assert abs(m[field] - statistics.mean(values)) < 1e-8, (arm, field)
    assert abs(m["correct_retained"] - (m["initial_correct"] + m["recovered"] - m["regressed"] -
               m["removed_correct"] + m["new_correct_from_unformed_original"])) < 1e-8
    rows.append([title] + [num(m[k]) for k in ["correct_retained", "recovered", "regressed", "removed_correct",
                                             "new_correct_from_unformed_original", "technical_failure"]] +
                [num(a5["logical_cost_by_arm"][arm]["logical_tokens_per_input_seed"])])
contrasts = {"TRACE_TYPED-TRACE_RAW": {"TRACE_TYPED": 1, "TRACE_RAW": -1},
             "DIRECT_TYPED-DIRECT_RAW": {"DIRECT_TYPED": 1, "DIRECT_RAW": -1},
             "TRACE_RAW-DIRECT_RAW": {"TRACE_RAW": 1, "DIRECT_RAW": -1},
             "typing_by_derivation_interaction": {"TRACE_TYPED": 1, "TRACE_RAW": -1, "DIRECT_TYPED": -1, "DIRECT_RAW": 1}}
totals = {task: {arm: [0, 0] for arm in arms} for task in task_frame}
for row in a5_evaluations:
    item = totals[row["task_id"]][row["arm"]]
    item[0] += bool(row["correct_retained"])
    item[1] += 1
assert all(len({counts[1] for counts in x.values()}) == 1 for x in totals.values())
denominator = sum(x[arms[0]][1] for x in totals.values())
for name, weights in contrasts.items():
    numerator = {task: sum(weight * totals[task][arm][0] for arm, weight in weights.items()) for task in task_frame}
    point = sum(numerator.values()) / denominator
    saved = main_a5["contrasts"][name]
    assert point == saved["point"]
with (a5_root / "type_audit.jsonl").open() as stream:
    audit = [json.loads(line) for line in stream if line.strip()]
assert len(audit) == 378
assert sum(x["predicted_status"] == "known" for x in audit) == a5["type_summary"]["known_tasks"]
assert sum(x["excludes_observed_type"] is True for x in audit) == a5["type_summary"]["known_tasks_excluding_observed_type"]
evidence["mbppplus_coverage"] = {"source": "a5_mbppplus_full/publication_results.json", "rows": rows,
    "contrasts": main_a5["contrasts"], "type_summary": a5["type_summary"], "cost": a5["cost"], "error_layers": a5_error_layers}
caption = ("Automatic types and derivation across all 378 MBPP+ tasks, with four fixed input slots per task and three seeds. "
           "Counts are seed means over 1,512 slots (1,511 distinct inputs); unadjudicable reference outputs remain in the coverage denominator. "
           "$R$, $H$, and $D$ are relative to the same input/seed's direct-raw assertion. $G$ counts correct outputs when that baseline retains no executable assertion; "
           "$F$ counts response or assertion-formation failures. Type-unknown conditions reuse the identical raw response. "
           "Tokens per input/seed include the typed policies' shared extraction setup, amortized over four inputs and three generation seeds.")
table("mbppplus_coverage", caption, "tab:mbppplus_coverage",
      ["Condition", "$U/1512$", "$R$", "$H$", "$D$", "$G$", "$F$", "Tokens/input-seed"], rows, wide=True, spec="lrrrrrrr")


# Five-model full-task confirmation; each table is checked against evaluations.
from a6_analysis import main as analyze_a6
a6=analyze_a6()
def pair(x,y):return num(x)+r"$\to$"+num(y)
def taskcell(d):return f'{d["task_improved"]}/{d["task_worsened"]}/{d["task_tied"]}'
rows=[]
for m in a6['models']:
    he=m['humaneval'];c=he['main_conflicts'];g=he['guards_observed'];f=he['all_formed_originals_reference_adjudicable'];z=he['all_fixed_slots']
    value=lambda x:pair(x['means']['visible']['correct_retained'],x['means']['hidden']['correct_retained'])
    rows.append([m['label'],value(c),num(c['delta_pp']),taskcell(c),value(g),num(g['delta_pp']),value(f),value(z)])
evidence['five_model_visibility']={'source':'ccfa-workfiles/manuscript/icse-oracle/build/a6_results.json','rows':rows}
table('five_model_visibility','Five-model visibility comparison on the same 164 HumanEval tasks and frozen Qwen3.5-9B originals and candidate implementations. Each pair reports visible to hidden useful retention, averaged over three seeds. Conflicts have 227 inputs from 86 active tasks; guards have 644 inputs, formed originals 891, and the full frame 1,312. Conflict task counts are improved/worsened/tied after summing paired seeds. Deltas are percentage points within each cohort. The full frame includes new correct outputs from unformed originals.', 'tab:five_visibility',['Checkpoint','$U$ conflicts','$\\Delta$ pp','Tasks +/--/=','$U$ guards','$\\Delta$ pp','$U$ formed','$U$ all'],rows,wide=True,spec='lrrrrrrr')
rows=[]
for m in a6['models']:
    b=m['mbppplus'];g=b['all_fixed_slots'];c=g['contrasts']['TRACE_TYPED-TRACE_RAW']
    rows.append([m['label'],b['type_summary']['known_tasks']]+[num(g['means'][a]['correct_retained']) for a in ['DIRECT_RAW','TRACE_RAW','DIRECT_TYPED','TRACE_TYPED']]+[num(c['delta_pp']),taskcell(c)])
evidence['five_model_types']={'source':'ccfa-workfiles/manuscript/icse-oracle/build/a6_results.json','rows':rows}
table('five_model_types','Five-model factorial comparison on all 378 MBPP+ tasks. $U$ is the three-seed mean over 1,512 fixed input slots. DR/TR denote direct/derivation with raw grammar; DT/TT use automatic types. Known counts usable type predictions out of 378. Type gain is TT minus TR in percentage points; task counts are improved/worsened/tied. All DeepSeek type predictions fall back, so its typed conditions reuse the identical raw responses; their zero contrast records no active type restriction.', 'tab:five_types',['Checkpoint','Known','$U_{DR}$','$U_{TR}$','$U_{DT}$','$U_{TT}$','Type gain','Tasks +/--/='],rows,wide=True,spec='lrrrrrrr')
rows=[]
for m in a6['action_models']:
    d=m['diagnostics'];p=m['policies'];b=m['binding']['bound']['counts']
    assert d['attempts']==d['valid']==192
    arr=lambda k:str(p['raw'][k])+r'$\to$'+str(p['bound'][k])
    rows.append([m['label'],d['rule_mismatch'],f'{d["rule_mismatch_when_decision_fields_correct"]}/{d["decision_fields_correct"]}',arr('regression'),arr('recovery'),arr('useful'),f'{b["harm_prevented_to_keep"]}/{b["harm_prevented_to_defer"]}',f'{b["recovery_lost"]}/{b["recovery_gained"]}'])
evidence['five_model_actions']={'source':'ccfa-workfiles/manuscript/icse-oracle/build/a6_results.json','rows':rows}
table('five_model_actions','Current five-model panel, with 192 valid responses per model on the same 12 finite families, 96 correct originals, and 48 repairable cases. $E$ counts action-rule errors; $E_c/C$ counts errors among responses with all three correct decision fields. Pairs show direct to status-first bound outcomes. Protection K/D decomposes prevented harmful repairs into KEEP/DEFER. Lost/gained counts recovery turnover. Qwen and Gemma rows reuse A2/A3; DeepSeek is newly collected. Historical Llama results remain in Tables~\\ref{tab:cross_layers} and~\\ref{tab:cross_outcomes}.', 'tab:five_actions',['Checkpoint','$E$','$E_c/C$','$H$','$R$','$U$','Protection K/D','Lost/gained'],rows,wide=True,spec='lrrrrrrr')

# Supplementary diagnostics retain the primary denominators and first responses.
from a6_review_checks import main as analyze_diagnostics
diagnostics = analyze_diagnostics()
diagnostic_source = "ccfa-workfiles/manuscript/icse-oracle/build/a6_review_checks.json"
short_labels = ["Qwen3.5-9B", "Qwen3.8-27B", "Qwen3.5-35B-A3B", "Gemma-4-26B-A4B-it", "DeepSeek-Coder-6.7B"]
rows = []
for model, title in zip(a6["models"], short_labels):
    data = diagnostics["models"][model["key"]]["humaneval"]
    for scope, label in [("main_conflicts", "Conflict"), ("guards_observed", "Guard")]:
        means = data[scope]["primary_means"]
        fields = ["correct_retained", "recovered", "regressed", "removed_correct", "technical_failure"]
        rows.append([title, label] + [f'{means["hidden"][k]-means["visible"][k]:+.2f}' for k in fields])
evidence["five_model_visibility_decomposition"] = {"source": diagnostic_source, "rows": rows}
table("five_model_visibility_decomposition",
      r"HumanEval outcome decomposition: hidden minus visible, in three-seed mean counts. Conflict and guard denominators are 227 and 644 inputs, with 27 and 630 correct originals, respectively. Each row obeys $\Delta U=\Delta R-\Delta H-\Delta D$ before rounding. $D$ includes withheld correct assertions from semantic deferral or technical failure. $F$ counts all technical failures, including failures on wrong originals; its overlap with $D$ must not be added again.",
      "tab:visibility_decomposition", ["Checkpoint", "Cohort", r"$\Delta U$", r"$\Delta R$", r"$\Delta H$", r"$\Delta D$", r"$\Delta F$"], rows, wide=True)

rows = []
for model, title in zip(a6["models"], short_labels):
    data = diagnostics["models"][model["key"]]["humaneval"]
    cells = [title]
    for scope in ["main_conflicts", "guards_observed"]:
        sub = data[scope]["common_technical_available"]
        cells += [sub["input_seed_pairs"], str(sub["visible_U"]) + r"$\to$" + str(sub["hidden_U"]), f'{sub["delta_pp"]:+.2f}']
    rows.append(cells)
evidence["five_model_visibility_available"] = {"source": diagnostic_source, "rows": rows}
table("five_model_visibility_available",
      r"HumanEval availability diagnostic on paired input--seed responses with no technical failure or unstarted dependency in either arm. Semantic DEFER remains eligible. $n$ is the number of response pairs; $U$ is their pooled useful-retention count from visible to hidden. Changes are percentage points within that conditional subset. This post-outcome selection supplements the all-attempt results in Table~\ref{tab:five_visibility}; its different denominator prevents subtraction of the two rates to estimate a technical-failure contribution.",
      "tab:visibility_available", ["Checkpoint", "Conflict $n$", "Conflict $U$", r"$\Delta$ pp", "Guard $n$", "Guard $U$", r"$\Delta$ pp"], rows, wide=True)

rows = []
for model, title in zip(a6["models"], short_labels):
    data = diagnostics["models"][model["key"]]["mbppplus"]
    cells = [title, data["type_summary"]["known_tasks"]]
    for scope in ["all_fixed_slots", "known_type", "observed_type_compatible", "all_four_valid"]:
        value = data[scope]["delta_pp"]["TRACE_TYPED-TRACE_RAW"]
        cells.append("N/A" if value is None else f"{value:+.2f}")
    cells.append(data["all_four_valid"]["input_seed_pairs"])
    rows.append(cells)
evidence["five_model_type_diagnostics"] = {"source": diagnostic_source, "rows": rows}
table("five_model_type_diagnostics",
      r"Automatic-type diagnostics on MBPP+: derivation with types minus derivation with raw grammar (TT--TR), in percentage points. Known is the number of usable type predictions out of 378 tasks. All uses all 1,512 slots; Known subset restricts to usable predictions; Compatible further requires agreement with the observed reference type at the input. Common valid requires all four conditions to form valid responses at the same input and seed, retaining semantic DEFER; its $n$ counts input--seed pairs across three seeds. N/A denotes an empty subset. DeepSeek's zero contrasts reflect identical raw fallback responses, with no active type restriction. Conditional subsets are diagnostic and model specific, not independent semantic labels or common cross-model cohorts.",
      "tab:type_diagnostics", ["Checkpoint", "Known", "All", "Known subset", "Compatible", "Common valid", "$n$"], rows, wide=True)

family_labels = {
    "adjacent_absolute_difference_total": "Adjacent absolute-difference total",
    "strict_inversion_count": "Strict inversion count",
    "strict_interior_peak_count": "Strict interior peak count",
    "first_repeated_entry_index": "First repeated entry index",
    "longest_nondecreasing_contiguous_run": "Longest nondecreasing contiguous run",
    "nonzero_sign_change_count": "Nonzero sign-change count",
    "any_most_frequent_value": "Any most frequent value",
    "any_least_frequent_present_value": "Any least frequent present value",
    "any_nearest_to_zero_value": "Any nearest-to-zero value",
    "any_adjacent_pair_sum": "Any adjacent-pair sum",
    "any_nonempty_proper_prefix_sum": "Any nonempty proper-prefix sum",
    "any_positive_pairwise_absolute_difference": "Any positive pairwise absolute difference",
}
groups = diagnostics["deepseek_action"]["groups"]
strata = [("family_" + k, v) for k, v in family_labels.items()] + [("seed_46001", "Seed 46001"), ("seed_46002", "Seed 46002"), ("all", "All responses")]
fields = ["n", "correct_decision_fields", "rule_errors", "correct_fields_rule_errors", "correct_fields_harm"]
rows = [[label] + [groups[key][f] for f in fields] for key, label in strata]
evidence["deepseek_action_strata"] = {"source": diagnostic_source, "rows": rows}
table("deepseek_action_strata",
      r"DeepSeek finite-panel family and seed breakdown. All $n$ responses are valid; $C$ has correct requirement status and both assertion-validity fields. $E$ counts all action-rule violations, $E_c$ those within $C$, and $H_c$ harmful direct repairs within $C$. The eight such harms span five families: one execution conflict and seven guards. Family and seed rows are two partitions of the same 192 responses, not additional samples. Configurations and seeds remain nested within 12 families.",
      "tab:deepseek_strata", ["Family or seed", "$n$", "$C$", "$E$", "$E_c$", "$H_c$"], rows, wide=True)

from a7_analysis import main as a7_replay
a7_historical = a7_replay()
from a7_correction_analysis import main as a7_correction_replay
from interface_audit_analysis import main as interface_audit_replay
a7 = a7_correction_replay()
interface_audit = interface_audit_replay()
a7_labels = {"qwen": "Qwen9B", "gemma": "Gemma"}
rows = []
decomposition = []
for source in ["qwen", "gemma"]:
    for judge in ["qwen", "gemma"]:
        for scope, label in [("formed_originals", "Formed originals"), ("conflicts", "Conflict"), ("guards", "Observed guard")]:
            b = a7["cells"][source + "/" + judge][scope]
            m = b["means"]
            delta_pp = "N/A" if b["delta_pp"] is None else f'{b["delta_pp"]:+.2f}'
            rows.append([a7_labels[source], a7_labels[judge], label, b["unique_cases"], int(m["visible"]["initial_correct"]),
                         num(m["visible"]["correct_retained"]) + r"$\to$" + num(m["hidden"]["correct_retained"]), delta_pp])
            d = b["delta"]
            direction = b["task_direction"]
            decomposition.append([a7_labels[source], a7_labels[judge], label] +
                [f'{d[f]:+.2f}' for f in ["recovered", "regressed", "removed_correct", "technical_failure"]] +
                ["/".join(f'{x:+d}' for x in b["delta_u_per_seed"]),
                 "/".join(str(direction[k]) for k in ["improved", "worsened", "tied"])])
correction_source = "a7_cross_source/code_repair/publication/data.json"
evidence["cross_source_visibility"] = {"source": correction_source, "rows": rows}
table("cross_source_visibility",
      r"Corrected-code source comparison on the same 40 hash-selected HumanEval tasks and eight inputs each. Both sources regenerate 160 implementations with flexible JSON whitespace; prompts, seeds and output budgets are unchanged. New executions determine source-specific conflict/guard labels after the archived judgments. All original assertions and judgment responses are reused unchanged. $n$ counts reference-adjudicable inputs and $C_0$ correct originals; $U$ is the three-seed mean, visible to hidden. Source-specific cohorts can differ; identical cached responses are shared observations.",
      "tab:cross_source_visibility", ["Source", "Judge", "Cohort", "$n$", "$C_0$", r"$U$: visible$\to$hidden", r"$\Delta$ pp"], rows, wide=True)
evidence["cross_source_decomposition"] = {"source": correction_source, "rows": decomposition}
table("cross_source_decomposition",
      r"Outcome accounting for the corrected-code cohorts in Table~\ref{tab:cross_source_visibility}: hidden minus visible in mean counts. Each row satisfies $\Delta U=\Delta R-\Delta H-\Delta D$ before rounding. Technical failure $F$ can overlap correct withholding $D$ and is not added again. Seed differences follow 47001/47002/47003. Task directions combine inputs and seeds within tasks containing cohort members. Only cohort membership changes; all original and final correctness judgments are inherited.",
      "tab:cross_source_decomposition", ["Source", "Judge", "Cohort", r"$\Delta R$", r"$\Delta H$", r"$\Delta D$", r"$\Delta F$", r"$\Delta U$ by seed", "Tasks +/--/="], decomposition, wide=True)

rows=[]
for mid in ["qwen", "gemma"]:
    c=a7["code"][mid]["counts"]
    cohort=a7["cells"][mid+"/qwen"]
    rows.append([a7_labels[mid],f'{c["old_syntax_pass"]}/160',f'{c["new_syntax_pass"]}/160',
                 f'{c["old_wire_failure"]}/{c["new_wire_failure"]}',c["new_named_function"],
                 cohort["conflicts"]["unique_cases"],cohort["guards"]["unique_cases"]])
evidence["code_interface_correction"]={"source":correction_source,"rows":rows}
table("code_interface_correction",
      r"Authorized code-only interface correction. All 320 formal request bodies match their earlier requests exactly; only the service's guided-decoding whitespace setting changes. Syntax counts use unmodified code strings. Wire failures include incomplete responses and remain in the 160-attempt denominator. The named-entry column counts new modules defining the required top-level function. Conflict/guard counts include reference-adjudicable inputs. Original assertions and judgment calls are not regenerated.",
      "tab:code_correction",["Source","Syntax: old","Syntax: corrected","Wire: old/new","Named entry","Conflicts","Guards"],rows,wide=True)

rows=[]
for key,label in zip([m["key"] for m in a6["models"]],short_labels):
    g=interface_audit["models"][key]["humaneval"]["guards"]
    arm=g["arms"]
    fail=lambda a:sum(n for k,n in arm[a]["categories"].items() if k not in ["formed","semantic_defer","dependent_not_started"])
    rows.append([label,f'{fail("visible")}/{fail("hidden")}',
                 f'{arm["visible"]["invalid_literal_leading_delimiter"]}/{arm["hidden"]["invalid_literal_leading_delimiter"]}',
                 f'{arm["visible"]["correct_removed_technical"]}/{arm["hidden"]["correct_removed_technical"]}',
                 f'{g["all_attempts"]["delta_pp"]:+.2f}',g["common_technical_available"]["input_seed_pairs"],
                 f'{g["common_technical_available"]["delta_pp"]:+.2f}'])
evidence["historical_format_audit"]={"source":"a7_cross_source/code_repair/format_audit/data.json","rows":rows}
table("historical_format_audit",
      r"Offline audit of historical HumanEval guards under compact guided decoding. Each arm contains 1,932 input--seed pairs (644 inputs, three seeds). Slash counts are visible/hidden. $F$ includes length, invalid-literal and assertion-contract failures; prefix counts are rejected literals beginning with a colon, closing brace, comma, or greater-than after whitespace. $D_F$ counts initially correct assertions lost to technical failure. Prefix signatures do not establish the cause of individual historical failures. Joint availability excludes pairs with a technical failure in either arm and retains semantic deferral; its denominator differs from the all-attempt comparison.",
      "tab:format_audit",["Model","$F$ V/H","Prefix V/H","$D_F$ V/H",r"All $\Delta$ pp","Joint $n$",r"Joint $\Delta$ pp"],rows,wide=True)

from judge_repair_tables import render as render_judge_repair
render_judge_repair(table,evidence,num)

dest = ROOT / "ccfa-workfiles/manuscript/icse-oracle/build/table_evidence.json"
dest.write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"Rendered {len(evidence)} tables from existing summaries.")

# Final publication scope is a separate projection. All historical tables above
# remain unchanged and reproducible in their original namespace.
from icpc_publication import main as render_icpc_publication
render_icpc_publication()
