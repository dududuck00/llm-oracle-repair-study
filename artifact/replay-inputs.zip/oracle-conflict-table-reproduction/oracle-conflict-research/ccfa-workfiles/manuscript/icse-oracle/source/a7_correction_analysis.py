"""Portable independent replay of the authorized code-only source correction."""
import hashlib,json
from collections import Counter
from pathlib import Path
from a7_analysis import reaggregate
ROOT=Path(__file__).resolve().parents[4]
def main():
    base=ROOT/'a7_cross_source/code_repair'
    p=base/'publication/data.json';data=json.loads(p.read_text())
    old=json.loads((ROOT/'a7_cross_source/publication/data.json').read_text())
    out=reaggregate(data);prior=reaggregate(old)
    assert data['selected_task_ids']==old['selected_task_ids']
    for cell,rs in data['evaluations'].items():
        for r,previous in zip(rs,old['evaluations'][cell]):
            ignore={'subgroup','any_conflict','candidate_conflict_count'}
            assert {k:v for k,v in r.items() if k not in ignore}=={k:v for k,v in previous.items() if k not in ignore}
        for name in ('all_fixed_slots','formed_originals','common_formed'):
            assert out['cells'][cell][name]==prior['cells'][cell][name]
    code={}
    for mid,c in data['code_checks'].items():
        counts={'formal_requests':len(c['rows'])}
        for era in ('old','new'):
            counts[era+'_syntax_pass']=sum(r[era]['syntax_pass'] for r in c['rows'])
            counts[era+'_named_function']=sum(r[era]['named_function'] for r in c['rows'])
            counts[era+'_wire_failure']=sum(r[era]['wire_failure'] for r in c['rows'])
            counts[era+'_syntax_failure']=sum(not r[era]['wire_failure'] and not r[era]['syntax_pass'] for r in c['rows'])
        for k,v in counts.items():assert v==c['counts'][k]
        assert counts['formal_requests']==c['exact_request_body_matches']==160
        cohort=Counter(r['subgroup'] for r in data['labels'][mid].values())
        assert dict(cohort)==c['cohort']['subgroups']
        assert not c['cohort']['frozen_before_repair'] and c['cohort']['code_only_regrouping_reuses_existing_judgments']
        code[mid]=dict(counts=counts,cohort=dict(cohort),candidate_execution_statuses=c['execution_statuses'])
    out.update(passed=True,code=code,cost=data['verified_summary']['cost'],all_outcomes_reused_unchanged=True,
               formal_requests=320,model_calls=0,no_intervals=True,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    dest=ROOT/'ccfa-workfiles/manuscript/icse-oracle/build/a7_correction_results.json'
    dest.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    return out
if __name__=='__main__':
    r=main();print(json.dumps(dict(passed=r['passed'],code=r['code'],common=r['common_cohorts'])))
