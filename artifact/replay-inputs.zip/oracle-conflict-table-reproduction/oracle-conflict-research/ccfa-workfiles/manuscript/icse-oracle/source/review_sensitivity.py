"""Recompute manuscript-review sensitivities from immutable A2 evaluations.

This is a post-hoc descriptive analysis. It performs no inference, leaves the
registered A2 outputs unchanged, and writes only the manuscript build artifact.
"""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
BUILD = ROOT / "ccfa-workfiles/manuscript/icse-oracle/build"
MODELS = ("qwen35_9b", "llama31_8b")
SEEDS = (46001, 46002)
SOURCES = (
    "a2_cross_model/evaluations.jsonl",
    "a2_cross_model/summary.json",
    "a2_cross_model/families.json",
    "a2_cross_model/verification.json",
)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def correct_decision_fields(row):
    prediction, gold = row["prediction"], row["gold"]
    return bool(row["valid"] and
                prediction["requirement_status"] == gold["status"] and
                prediction["original_validity"] == gold["original"] and
                prediction["proposal_validity"] == gold["proposal"])


def rule_error(row):
    return bool(row["valid"] and row["raw_action"] != row["bound_action"])


def harmful_repair(row):
    gold = row["gold"]
    return bool(row["valid"] and gold["original"] == "supported" and
                row["raw_action"] == "REPAIR" and gold["proposal"] != "supported")


def counts(rows):
    correct = [r for r in rows if correct_decision_fields(r)]
    correct_errors = [r for r in correct if rule_error(r)]
    return dict(
        attempted=len(rows), valid=sum(bool(r["valid"]) for r in rows),
        technical_failures=sum(not r["valid"] for r in rows),
        rule_errors=sum(rule_error(r) for r in rows),
        decision_fields_correct=len(correct),
        rule_errors_when_decision_fields_correct=len(correct_errors),
        harmful_repairs=sum(harmful_repair(r) for r in rows),
        harmful_repairs_when_decision_fields_correct=sum(harmful_repair(r) for r in correct),
        correct_field_error_scope={scope: sum(r["conflict"] == (scope == "conflict") for r in correct_errors)
                                   for scope in ("conflict", "guard")},
    )


def check_summary(actual, reference):
    diagnostics, policy = reference["diagnostics"], reference["policies"]["raw"]
    mappings = {
        "attempted": "attempts", "valid": "valid", "technical_failures": "technical_failure",
        "rule_errors": "rule_mismatch", "decision_fields_correct": "decision_fields_correct",
        "rule_errors_when_decision_fields_correct": "rule_mismatch_when_decision_fields_correct",
        "harmful_repairs_when_decision_fields_correct": "harm_when_decision_fields_correct",
    }
    for left, right in mappings.items():
        assert actual[left] == diagnostics[right], (left, actual[left], diagnostics[right])
    assert actual["harmful_repairs"] == policy["regression"]


def main():
    before = {name: sha(ROOT / name) for name in SOURCES}
    verification = read("a2_cross_model/verification.json")
    assert verification["passed"]
    for name in ("evaluations.jsonl", "summary.json"):
        assert before["a2_cross_model/" + name] == verification["output_sha256"][name]
    rows = [json.loads(line) for line in (ROOT / SOURCES[0]).read_text(encoding="utf-8").splitlines()]
    summary = read("a2_cross_model/summary.json")
    families = read("a2_cross_model/families.json")
    family_ids = [f["id"] for f in families]
    assert len(rows) == 384 and len({r["id"] for r in rows}) == 384
    by_model = {model: [r for r in rows if r["model_id"] == model] for model in MODELS}
    assert all(len(selected) == 192 for selected in by_model.values())
    indexes = {model: {r["panel"]: r for r in selected} for model, selected in by_model.items()}
    assert set(indexes[MODELS[0]]) == set(indexes[MODELS[1]])
    common = sorted(panel for panel in indexes[MODELS[0]]
                    if all(correct_decision_fields(indexes[model][panel]) for model in MODELS))
    common_valid = sorted(panel for panel in indexes[MODELS[0]]
                          if all(indexes[model][panel]["valid"] for model in MODELS))
    assert len(common) == 51 and len(common_valid) == 186

    out = dict(
        analysis_kind="posthoc_descriptive_sensitivity",
        no_new_model_calls=True,
        primary_endpoint_unchanged="Registered A2 all-attempt outcomes remain primary.",
        statistical_unit="Repeated response pairs nested in twelve finite families; no population significance test.",
        decision_fields=["requirement_status", "original_validity", "proposal_validity"],
        selection="Both models valid and all three action-decision fields match the frozen authored contract at the same panel ID.",
        inputs_sha256_before=before,
        common_correct_decision_fields=dict(pairs=len(common), panel_ids=common, models={}),
        common_valid_pairs=len(common_valid),
        models={}, family_seed=[],
    )
    for model in MODELS:
        chosen = by_model[model]
        overall = counts(chosen)
        check_summary(overall, summary["models"][model]["all"])
        errors = [r for r in chosen if correct_decision_fields(r) and rule_error(r)]
        out["models"][model] = dict(
            all=overall,
            by_seed={str(seed): counts([r for r in chosen if r["seed"] == seed]) for seed in SEEDS},
            correct_field_error_families=dict(sorted(Counter(r["gold"]["family"] for r in errors).items())),
            correct_field_error_ids=sorted(r["id"] for r in errors),
        )
        for seed in SEEDS:
            check_summary(out["models"][model]["by_seed"][str(seed)], summary["models"][model][f"seed_{seed}"])
        for family in family_ids:
            check_summary(counts([r for r in chosen if r["gold"]["family"] == family]),
                          summary["models"][model]["family_" + family])
        for key in ("attempted", "valid", "technical_failures", "rule_errors", "decision_fields_correct",
                    "rule_errors_when_decision_fields_correct", "harmful_repairs", "harmful_repairs_when_decision_fields_correct"):
            assert sum(out["models"][model]["by_seed"][str(seed)][key] for seed in SEEDS) == overall[key]
        common_rows = [indexes[model][panel] for panel in common]
        z = counts(common_rows)
        z["error_ids"] = sorted(r["id"] for r in common_rows if rule_error(r))
        out["common_correct_decision_fields"]["models"][model] = z

    for family in families:
        for seed in SEEDS:
            strata = dict(family=family["id"], regime=family["regime"], seed=seed, models={})
            for model in MODELS:
                selected = [r for r in by_model[model] if r["gold"]["family"] == family["id"] and r["seed"] == seed]
                assert len(selected) == 8
                strata["models"][model] = counts(selected)
            out["family_seed"].append(strata)
    assert len(out["family_seed"]) == 24
    for model in MODELS:
        for key in ("attempted", "valid", "technical_failures", "rule_errors", "decision_fields_correct",
                    "rule_errors_when_decision_fields_correct", "harmful_repairs", "harmful_repairs_when_decision_fields_correct"):
            assert sum(stratum["models"][model][key] for stratum in out["family_seed"]) == out["models"][model]["all"][key]

    common_q, common_l = (out["common_correct_decision_fields"]["models"][m] for m in MODELS)
    assert common_q["rule_errors"] == common_q["harmful_repairs"] == 0
    assert common_l["rule_errors"] == common_l["harmful_repairs"] == 7
    assert common_l["correct_field_error_scope"] == dict(conflict=2, guard=5)
    llama = out["models"]["llama31_8b"]
    assert llama["all"]["rule_errors_when_decision_fields_correct"] == 8
    assert llama["all"]["correct_field_error_scope"] == dict(conflict=3, guard=5)
    assert len(llama["correct_field_error_families"]) == 5
    assert llama["correct_field_error_families"]["any_adjacent_pair_sum"] == 4
    assert [llama["by_seed"][str(seed)]["rule_errors_when_decision_fields_correct"] for seed in SEEDS] == [1, 7]

    after = {name: sha(ROOT / name) for name in SOURCES}
    assert before == after
    out["inputs_sha256_after"] = after
    out["checks"] = dict(
        frozen_analysis_output_hashes_match=True, primary_summary_counts_match=True,
        family_and_seed_partitions_conserve_counts=True, common_panel_selection_verified=True,
        scope_and_concentration_counts_verified=True, source_files_unchanged=True,
    )
    out["passed"] = True
    BUILD.mkdir(parents=True, exist_ok=True)
    (BUILD / "review_sensitivity.json").write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(dict(passed=True, common_correct_pairs=len(common), rule_errors=[common_q["rule_errors"], common_l["rule_errors"]], family_seed_strata=24, new_model_calls=0)))


if __name__ == "__main__":
    main()
