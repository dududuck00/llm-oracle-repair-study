"""Descriptive A6 supplementary analyses; no inference or interval estimates.

Run from any directory. Writes only the adjacent build/a6_review_checks.json.
Primary all-attempt results remain unchanged. Common-available subsets are
post-outcome diagnostics, not replacements for the primary estimand.
"""
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
OUTPUT = Path(__file__).resolve().parent.parent / "build/a6_review_checks.json"
SOURCES = {}


def read(relative, jsonl=False):
    data = (ROOT / relative).read_bytes()
    SOURCES[relative] = hashlib.sha256(data).hexdigest()
    text = data.decode("utf-8")
    return [json.loads(line) for line in text.splitlines()] if jsonl else json.loads(text)


def contrast(value):
    return None if value is None else value * 100


def main():
    current = read("ccfa-workfiles/manuscript/icse-oracle/build/a6_results.json")
    paths = [
        ("qwen35_9b", "a4_humaneval_full_v2", "a5_mbppplus_full"),
        ("qwen38_27b", "a6_five_model_full/qwen38_27b/humaneval", "a6_five_model_full/qwen38_27b/mbppplus"),
        ("qwen35_35b_a3b", "a6_five_model_full/qwen35_35b_a3b_admission_v3/humaneval", "a6_five_model_full/qwen35_35b_a3b_admission_v3/mbppplus"),
        ("gemma4_26b_a4b_it", "a6_five_model_full/gemma4_26b_a4b_it/humaneval", "a6_five_model_full/gemma4_26b_a4b_it/mbppplus"),
        ("deepseek_coder_67b", "a6_five_model_full/deepseek_coder_67b_native_v3/humaneval", "a6_five_model_full/deepseek_coder_67b_native_v4_completed/mbppplus"),
    ]
    result = dict(model_calls=0, inferential_intervals=False, models={},
                  scope="Descriptive review diagnostics; all original denominators retained in primary results.")
    current_by_key = {m["key"]: m for m in current["models"]}
    for key, hp, mp in paths:
        he = read(f"a6_five_model_full/publication/{key}_humaneval.json")
        mb = read(f"a6_five_model_full/publication/{key}_mbppplus.json")
        rows = read(hp + "/evaluations.jsonl", jsonl=True)
        pairs = defaultdict(dict)
        for row in rows:
            pair = pairs[(row["case_id"], row["seed"])]
            assert row["arm"] not in pair
            pair[row["arm"]] = row
        assert all(set(pair) == {"visible", "hidden"} for pair in pairs.values())
        item = dict(humaneval={}, mbppplus={}, seed_direction={})
        result["models"][key] = item
        for name, subgroup in [("main_conflicts", "conflict"), ("guards_observed", "guard")]:
            primary = current_by_key[key]["humaneval"][name]
            subset = [p for p in pairs.values() if p["visible"]["subgroup"] == subgroup
                      and all(not r["technical_failure"] and not r["dependent_not_started"] for r in p.values())]
            u = {arm: sum(p[arm]["correct_retained"] for p in subset) for arm in ["visible", "hidden"]}
            item["humaneval"][name] = {
                "primary_delta_pp": primary["delta_pp"],
                "primary_means": {
                    arm: {k: vals[k] for k in ["n", "correct_retained", "initial_correct", "recovered", "regressed", "removed_correct", "technical_failure", "semantic_defer"]}
                    for arm, vals in primary["means"].items()
                },
                "common_technical_available": {
                    "definition": "Both responses have no technical_failure and no dependent_not_started; semantic DEFER remains eligible.",
                    "input_seed_pairs": len(subset), "tasks": len({p["visible"]["task_id"] for p in subset}),
                    "visible_U": u["visible"], "hidden_U": u["hidden"],
                    "delta_pp": contrast((u["hidden"] - u["visible"]) / len(subset)) if subset else None,
                },
            }
            for vals in primary["means"].values():
                assert abs(vals["correct_retained"] - (vals["initial_correct"] + vals["recovered"] - vals["regressed"] - vals["removed_correct"])) < 1e-7
            item["seed_direction"][name] = {
                seed: p["hidden"]["correct_retained"] - p["visible"]["correct_retained"]
                for seed, p in primary["per_seed"].items()
            }
        sensitive = he["analyses"]["main_conflicts_reference_sensitive_excluded"]
        item["humaneval"]["reference_sensitive_excluded"] = {
            "inputs": sensitive["unique_cases"],
            "delta_pp": contrast(sensitive["hidden_minus_visible_correct_retained"]["point"]),
        }
        for name in ["all_fixed_slots", "known_type", "observed_type_compatible", "all_four_valid", "unique_input_sensitivity"]:
            a = mb["analyses"][name]
            pairs_per_seed = {seed: p["DIRECT_RAW"]["n"] for seed, p in a["per_seed"].items()}
            item["mbppplus"][name] = {
                "distinct_input_slots_in_subset": a["input_slots"], "tasks": a["tasks_with_slots"],
                "input_seed_pairs": sum(pairs_per_seed.values()), "pairs_per_seed": pairs_per_seed,
                "delta_pp": {k: contrast(c["point"]) for k, c in a["contrasts"].items()},
            }
        item["mbppplus"]["type_summary"] = mb["type_summary"]
        a = current_by_key[key]["mbppplus"]["all_fixed_slots"]
        item["seed_direction"]["raw_derivation"] = {
            seed: p["TRACE_RAW"]["correct_retained"] - p["DIRECT_RAW"]["correct_retained"] for seed, p in a["per_seed"].items()
        }
        item["seed_direction"]["typed_derivation"] = {
            seed: p["TRACE_TYPED"]["correct_retained"] - p["TRACE_RAW"]["correct_retained"] for seed, p in a["per_seed"].items()
        }
    rows = read("a6_five_model_full/deepseek_coder_67b_native_v4_completed/action_panel/evaluations.jsonl", jsonl=True)
    groups = defaultdict(Counter)
    harm_rows = []
    bound_harm_rows = []
    for row in rows:
        pred, gold = row["prediction"], row["gold"]
        assert row["valid"]
        correct = (pred["requirement_status"] == gold["status"] and pred["original_validity"] == gold["original"]
                   and pred["proposal_validity"] == gold["proposal"])
        raw_harm = row["raw_action"] == "REPAIR" and gold["original"] == "supported" and gold["proposal"] != "supported"
        if correct and raw_harm:
            harm_rows.append({k: row[k] for k in ["id", "seed", "conflict"]} | {"family": gold["family"]})
        if row["bound_action"] == "REPAIR" and gold["original"] == "supported" and gold["proposal"] != "supported":
            bound_harm_rows.append({"id": row["id"], "correct_decision_fields": correct})
        for key in ["all", "family_" + gold["family"], "seed_" + str(row["seed"])]:
            c = groups[key]
            c["n"] += 1
            c["correct_decision_fields"] += correct
            c["rule_errors"] += row["raw_action"] != row["bound_action"]
            c["correct_fields_rule_errors"] += correct and row["raw_action"] != row["bound_action"]
            c["correct_fields_harm"] += correct and raw_harm
    assert groups["all"] == dict(n=192, correct_decision_fields=24, rule_errors=33, correct_fields_rule_errors=9, correct_fields_harm=8)
    result["deepseek_action"] = dict(groups=groups, correct_field_harm_events=harm_rows,
                                     affected_families=len({x["family"] for x in harm_rows}),
                                     bound_harm_events=bound_harm_rows,
                                     correct_field_raw_harms_persisting_under_binding=len({x["id"] for x in harm_rows} & {x["id"] for x in bound_harm_rows}))
    assert len(bound_harm_rows) == 8 and not any(x["correct_decision_fields"] for x in bound_harm_rows)
    assert result["deepseek_action"]["correct_field_raw_harms_persisting_under_binding"] == 0
    result["checks"] = {
        "guard_negative_seed_comparisons": sum(v < 0 for m in result["models"].values() for v in m["seed_direction"]["guards_observed"].values()),
        "raw_derivation_positive_seed_comparisons": sum(v > 0 for m in result["models"].values() for v in m["seed_direction"]["raw_derivation"].values()),
        "typed_derivation_positive_seed_comparisons": sum(v > 0 for m in result["models"].values() for v in m["seed_direction"]["typed_derivation"].values()),
    }
    assert list(result["checks"].values()) == [15, 15, 12]
    result["source_sha256"] = SOURCES
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(OUTPUT.relative_to(ROOT)), "models": len(paths), "checks": result["checks"],
                      "deepseek_harm_families": result["deepseek_action"]["affected_families"], "model_calls": 0}, ensure_ascii=False))
    return result


if __name__ == "__main__":
    main()
