"""Portable aggregation of declared format-audit projections; no inference."""
import ast,hashlib,json
from collections import Counter,defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
def main():
    base=ROOT/'a7_cross_source/code_repair/format_audit'
    p=base/'data.json';d=json.loads(p.read_text());s=json.loads((base/'summary.json').read_text())
    cs=d['upstream_code_checks'];os=d['upstream_original_checks'];observed=d['upstream_candidate_observation']
    upstream=dict(code_requests=len(cs),original_requests=len(os),code_syntax_pass=sum(r['syntax_pass'] for r in cs),
        code_syntax_fail=sum(not r['wire_failure'] and not r['syntax_pass'] for r in cs),code_wire_failure=sum(r['wire_failure'] for r in cs),
        code_syntax_leading_delimiter=sum(r['leading_delimiter'] for r in cs),original_categories=dict(Counter(r['category'] for r in os)),
        original_invalid_literal_leading_delimiter=sum(r['invalid_literal_leading_delimiter'] for r in os),
        candidate_adjudicable_count_distribution={str(k):v for k,v in sorted(Counter(r['adjudicable_count'] for r in observed).items())},
        fully_observed_candidate_inputs=sum(r['complete'] for r in observed))
    assert upstream==s['upstream']
    result=dict(passed=True,model_calls=0,no_intervals=True,upstream=upstream,models={},source_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    for key,m in d['models'].items():
        rows=m['humaneval']['rows'];assert len(rows)==7872
        for r in rows:
            if r['category']=='invalid_literal':
                literal=r['expected_literal']
                assert isinstance(literal,str)
                assert r['invalid_literal_leading_delimiter']==literal.lstrip().startswith((':','}',',','>'))
                try:ast.literal_eval(literal.lstrip(' \t'))
                except (ValueError,SyntaxError):pass
                else:raise AssertionError('Projected invalid literal parsed successfully')
        groups={}
        for name,subgroup in [('conflicts','conflict'),('guards','guard')]:
            rs=[r for r in rows if r['subgroup']==subgroup and r['reference_adjudicable']]
            pair=defaultdict(dict)
            for r in rs:pair[(r['case_id'],r['seed'])][r['arm']]=r
            assert all(set(v)=={'visible','hidden'} for v in pair.values())
            arms={}
            for arm in ('visible','hidden'):
                ar=[r for r in rs if r['arm']==arm]
                arms[arm]=dict(logical_slots=len(ar),physical_response_ids=len({r['physical_id'] for r in ar if r['physical_id']}),
                    categories=dict(Counter(r['category'] for r in ar)),invalid_literal_leading_delimiter=sum(r['invalid_literal_leading_delimiter'] for r in ar),
                    initial_correct=sum(r['initial_correct'] for r in ar),correct_retained=sum(r['correct_retained'] for r in ar),
                    correct_removed_technical=sum(r['initial_correct'] and r['technical_failure'] for r in ar),
                    correct_removed_defer=sum(r['initial_correct'] and r['semantic_defer'] for r in ar),regressed=sum(r['regressed'] for r in ar))
            assert arms==s['models'][key]['humaneval']['groups'][name]['arms']
            g=dict(arms=arms)
            for label,ps in [('all_attempts',list(pair.values())),('common_technical_available',[v for v in pair.values() if all(not r['technical_failure'] and not r['dependent_not_started'] for r in v.values())])]:
                v=sum(p['visible']['correct_retained'] for p in ps);h=sum(p['hidden']['correct_retained'] for p in ps)
                point=100*(h-v)/len(ps) if ps else None
                expected=s['models'][key]['humaneval']['groups'][name][label]
                assert (len(ps),v,h,point)==(expected['input_seed_pairs'],expected['visible_U'],expected['hidden_U'],expected['delta_pp'])
                g[label]=dict(input_seed_pairs=len(ps),visible_U=v,hidden_U=h,delta_pp=point)
            groups[name]=g
        mb=m['mbppplus'];assert len(mb['rows'])==18144
        typ=mb['type_audit'];ex=mb['extraction_wire_categories']
        types=dict(tasks=len(typ),wire_failures=dict(Counter(r['wire_category'] for r in ex if r['wire_category'])),
            known=sum(r['predicted_status']=='known' for r in typ),fallback_reasons=dict(Counter(r['fallback_reason'] for r in typ if r['fallback_reason'])),
            reason_leading_delimiter=sum(r['reason_leading_delimiter'] for r in ex))
        assert types==s['models'][key]['mbppplus']['types']
        cats={a:dict(Counter(r['category'] for r in mb['rows'] if r['arm']==a)) for a in ['DIRECT_RAW','TRACE_RAW','DIRECT_TYPED','TRACE_TYPED']}
        assert all(cats[a]==s['models'][key]['mbppplus']['groups']['all_fixed_slots'][a]['categories'] for a in cats)
        result['models'][key]=dict(humaneval=groups,mbppplus=dict(types=types,categories=cats,physical_formal_requests=mb['physical_formal_requests']))
    assert sum(d['a6_action_validity'])==s['a6_action_panel']['valid']==192
    dest=ROOT/'ccfa-workfiles/manuscript/icse-oracle/build/interface_audit_results.json'
    dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    return result
if __name__=='__main__':
    r=main();print(json.dumps(dict(passed=r['passed'],models=len(r['models']),model_calls=0)))
