"""Independently reaggregate the four source/judge cells from evaluation fields."""
import collections,hashlib,json,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
FIELDS=['initial_correct','initial_wrong','correct_retained','recovered','regressed','removed_correct','new_correct_from_unformed_original','technical_failure','semantic_defer','dependent_not_started','retained']
SEEDS=[47001,47002,47003]
def block(rows):
 byseed={str(s):{arm:{'n':len(rs),**{f:sum(bool(x[f]) for x in rs) for f in FIELDS}} for arm in ['visible','hidden'] for rs in [[r for r in rows if r['seed']==s and r['arm']==arm]]} for s in SEEDS}
 mean={arm:{f:statistics.mean(byseed[str(s)][arm][f] for s in SEEDS) for f in ['n',*FIELDS]} for arm in ['visible','hidden']}
 for arm in mean:
  m=mean[arm];assert abs(m['correct_retained']-(m['initial_correct']+m['recovered']-m['regressed']-m['removed_correct']+m['new_correct_from_unformed_original']))<1e-8
 delta={f:mean['hidden'][f]-mean['visible'][f] for f in FIELDS}
 tasks=collections.defaultdict(lambda:dict(visible=0,hidden=0))
 for r in rows:tasks[r['task_id']][r['arm']]+=r['correct_retained']
 td={t:v['hidden']-v['visible'] for t,v in tasks.items()}
 return dict(n=mean['visible']['n'],unique_cases=len({r['case_id'] for r in rows}),tasks=len(tasks),means=mean,delta=delta,delta_pp=100*delta['correct_retained']/mean['visible']['n'] if mean['visible']['n'] else None,per_seed=byseed,delta_u_per_seed=[byseed[str(s)]['hidden']['correct_retained']-byseed[str(s)]['visible']['correct_retained'] for s in SEEDS],task_direction=dict(improved=sum(v>0 for v in td.values()),worsened=sum(v<0 for v in td.values()),tied=sum(v==0 for v in td.values())))
def reaggregate(data):
 labels=data['labels'];cells={}
 common={k for k in labels['qwen'] if all(labels[s][k]['before'] is not None and labels[s][k]['reference_adjudicable'] for s in labels)}
 common_c={k for k in common if all(labels[s][k]['any_conflict'] for s in labels)}
 common_g={k for k in common if all(labels[s][k]['subgroup']=='guard' for s in labels)}
 for cell,rows in data['evaluations'].items():
  assert len(rows)==1920 and len({(r['case_id'],r['seed'],r['arm']) for r in rows})==1920
  assert {r['task_id'] for r in rows}==set(data['selected_task_ids'])
  assert all(len({r['case_id'] for r in rows if r['task_id']==tid})==8 for tid in data['selected_task_ids'])
  pair=collections.defaultdict(list)
  for r in rows:pair[(r['case_id'],r['seed'])].append(r)
  valid={k for k,v in pair.items() if not any(r['technical_failure'] or r['dependent_not_started'] for r in v)}
  groups={'all_fixed_slots':lambda r:True,'conflicts':lambda r:r['any_conflict'] and r['reference_adjudicable'],'guards':lambda r:r['subgroup']=='guard' and r['reference_adjudicable'],'formed_originals':lambda r:r['original_wellformed'] and r['reference_adjudicable'],'common_formed':lambda r:r['case_id'] in common,'common_conflicts':lambda r:r['case_id'] in common_c,'common_guards':lambda r:r['case_id'] in common_g,'conflicts_technical_available':lambda r:r['any_conflict'] and r['reference_adjudicable'] and (r['case_id'],r['seed']) in valid,'guards_technical_available':lambda r:r['subgroup']=='guard' and r['reference_adjudicable'] and (r['case_id'],r['seed']) in valid,'conflicts_sensitive_excluded':lambda r:r['any_conflict'] and r['reference_adjudicable'] and r['task_id'] not in {'HumanEval/14','HumanEval/57','HumanEval/90'}}
  cells[cell]={g:block([r for r in rows if predicate(r)]) for g,predicate in groups.items()}
  for scope,value in cells[cell].items():
   expected=data['verified_summary']['cells'][cell][scope]
   for arm in ['visible','hidden']:
    for f in ['n',*FIELDS]:assert abs(value['means'][arm][f]-expected['mean_over_seeds'][arm][f])<1e-8,(cell,scope,arm,f)
   assert value['delta_u_per_seed']==[expected['delta_u_per_seed'][str(s)] for s in SEEDS]
 transitions=collections.Counter((labels['qwen'][k]['subgroup'],labels['gemma'][k]['subgroup']) for k in labels['qwen'])
 return dict(cells=cells,common_cohorts=dict(formed=len(common),conflicts=len(common_c),guards=len(common_g)),transitions=[dict(qwen_source=a,gemma_source=b,cases=n) for (a,b),n in sorted(transitions.items())])
def main():
 p=ROOT/'a7_cross_source/publication/data.json';data=json.loads(p.read_text());out=reaggregate(data)
 selection_path=ROOT/'a7_cross_source/selection.json';selection=json.loads(selection_path.read_text())
 assert selection['namespace']=='20261030/A7/HumanEval/task-v1'
 ranked=sorted((hashlib.sha256((selection['namespace']+'|HumanEval/'+str(i)).encode()).hexdigest(),'HumanEval/'+str(i)) for i in range(164))
 assert data['selected_task_ids']==selection['selected_task_ids']==[tid for _,tid in ranked[:40]]
 diagnostic=data['shared_candidate_diagnostic'];assert diagnostic['posthoc']
 d=reaggregate(dict(diagnostic,selected_task_ids=data['selected_task_ids']))
 for cell in out['cells']:
  for scope in ['all_fixed_slots','formed_originals','common_formed']:assert out['cells'][cell][scope]==d['cells'][cell][scope]
  primary=data['evaluations'][cell];secondary=diagnostic['evaluations'][cell]
  assert len(primary)==len(secondary)
  assert all({k:v for k,v in a.items() if k not in ['subgroup','any_conflict','candidate_conflict_count']}=={k:v for k,v in b.items() if k not in ['subgroup','any_conflict','candidate_conflict_count']} for a,b in zip(primary,secondary))
 d.update(posthoc=True,design=diagnostic['design'],original_code_failure=diagnostic['original_code_failure'],qwen_cohort_exactly_reproduced=diagnostic['qwen_cohort_exactly_reproduced'])
 out.update(passed=True,shared_candidate_diagnostic=d,cost=data['verified_summary']['cost'],repair_plan=data['verified_summary']['repair_plan'],source_projection_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),selection_sha256=hashlib.sha256(selection_path.read_bytes()).hexdigest(),hash_selection_reproduced=True,model_calls=0,intervals=False)
 dest=ROOT/'ccfa-workfiles/manuscript/icse-oracle/build/a7_results.json';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');return out
if __name__=='__main__':
 result=main();print(json.dumps(dict(passed=result['passed'],common=result['common_cohorts'],model_calls=0)))
