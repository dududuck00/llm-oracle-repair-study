"""Offline five-model comparison, reaggregated from frozen evaluations; no resampling."""
import json,hashlib,statistics,importlib.util
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
A6=ROOT/'a6_five_model_full'
def read(p):return json.loads(p.read_text())
def rows(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def scoped(r,name):
 if name=='main_conflicts':return r['any_conflict'] and r['reference_adjudicable']
 if name=='guards_observed':return r['subgroup']=='guard' and r['reference_adjudicable']
 if name=='all_formed_originals_reference_adjudicable':return r['original_wellformed'] and r['reference_adjudicable']
 return True

def main():
 results=[]
 for entry in read(A6/'publication/index.json'):
  key=entry['key'];res=dict(key=key,label=entry['label'],sources={})
  for ds in ['humaneval','mbppplus']:
   p=ROOT/entry[ds];s=read(A6/'publication'/f'{key}_{ds}.json');e=rows(p/'evaluations.jsonl')
   assert sha(p/'evaluations.jsonl')==s['projection']['source_sha256']['evaluations.jsonl']
   assert read(p/'verification.json')['passed']
   assert len(e)==(7872 if ds=='humaneval' else 18144)
   res['sources'][ds]=s['projection']
   groups=['main_conflicts','guards_observed','all_formed_originals_reference_adjudicable','all_fixed_slots'] if ds=='humaneval' else ['all_fixed_slots']
   out={}
   for name in groups:
    selected=[r for r in e if scoped(r,name)] if ds=='humaneval' else e
    g=s['analyses'][name];means=g['mean_over_seeds']
    for arm,m in means.items():
     for field in ['n','initial_correct','correct_retained','recovered','regressed','removed_correct','new_correct_from_unformed_original','technical_failure','semantic_defer']:
      if field not in m:continue
      totals=[sum(1 if field=='n' else bool(r[field]) for r in selected if r['arm']==arm and r['seed']==seed) for seed in s['seeds']]
      assert abs(statistics.mean(totals)-m[field])<1e-8,(key,ds,name,arm,field)
     assert abs(m['correct_retained']-(m['initial_correct']+m['recovered']-m['regressed']-m['removed_correct']+m['new_correct_from_unformed_original']))<1e-8
    item={'means':means,'per_seed':g['per_seed']}
    if ds=='humaneval':
     task=defaultdict(lambda:dict(visible=0,hidden=0))
     for r in selected:task[r['task_id']][r['arm']]+=bool(r['correct_retained'])
     d=[v['hidden']-v['visible'] for v in task.values()];point=(means['hidden']['correct_retained']-means['visible']['correct_retained'])/means['visible']['n']
     assert abs(point-g['hidden_minus_visible_correct_retained']['point'])<1e-12
     item.update(n=means['visible']['n'],delta_pp=100*point,task_improved=sum(x>0 for x in d),task_worsened=sum(x<0 for x in d),task_tied=sum(x==0 for x in d),active_tasks=len(d))
    else:
     weights={'TRACE_TYPED-TRACE_RAW':{'TRACE_TYPED':1,'TRACE_RAW':-1},'DIRECT_TYPED-DIRECT_RAW':{'DIRECT_TYPED':1,'DIRECT_RAW':-1},'TRACE_RAW-DIRECT_RAW':{'TRACE_RAW':1,'DIRECT_RAW':-1},'typing_by_derivation_interaction':{'TRACE_TYPED':1,'TRACE_RAW':-1,'DIRECT_TYPED':-1,'DIRECT_RAW':1}}
     task=defaultdict(lambda:defaultdict(int))
     for r in selected:task[r['task_id']][r['arm']]+=bool(r['correct_retained'])
     contrasts={}
     for name2,w in weights.items():
      d=[sum(w[a]*v[a] for a in w) for v in task.values()];point=sum(d)/(1512*3)
      assert abs(point-g['contrasts'][name2]['point'])<1e-12
      contrasts[name2]=dict(delta_pp=100*point,task_improved=sum(x>0 for x in d),task_worsened=sum(x<0 for x in d),task_tied=sum(x==0 for x in d))
     item.update(n=1512,contrasts=contrasts)
    out[name]=item
   if ds=='mbppplus':
    audit=rows(p/'type_audit.jsonl');assert len(audit)==378
    assert sum(r['predicted_status']=='known' for r in audit)==s['type_summary']['known_tasks']
    out['type_summary']=s['type_summary'];out['cost']=s['cost']
   else:out['cost']=s['cost']
   res[ds]=out
  results.append(res)
 # Replay the DeepSeek finite-panel statistics from evaluated first responses.
 action=A6/'deepseek_coder_67b_native_v4_completed/action_panel'
 spec=importlib.util.spec_from_file_location('a6_action_score',action/'a2_score.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
 ar=rows(action/'evaluations.jsonl');s=read(A6/'publication/deepseek_action.json');assert sha(action/'evaluations.jsonl')==s['projection']['source_sha256']['evaluations.jsonl']
 assert a.summarize(ar)==s['analyses']['all']
 action_models=[]
 q9=read(ROOT/'a2_cross_model/summary.json')['models']['qwen35_9b']['all'];q=read(ROOT/'a3_model_extension_v2/summary.json')['models'];gm=read(ROOT/'a3_gemma_interface_v3/summary.json')['models']
 groups=[q9,q['qwen38_27b']['all'],q['qwen35_35b_a3b']['all'],gm['gemma4_26b_a4b_it']['all'],s['analyses']['all']]
 for m,g in zip(results,groups):action_models.append(dict(key=m['key'],label=m['label'],**g))
 new_calls=new_tokens=0
 for m in results[1:]:
  c=m['humaneval']['cost'];b=m['mbppplus']['cost'];new_calls+=c['new_actual_calls']+b['actual_calls'];new_tokens+=c['new_measured_tokens']+b['measured_tokens']
 # v4 excludes two old MBPP engineering calls, which are retained once here.
 new_calls+=2+s['cost']['requests'];new_tokens+=1774+s['cost']['measured_tokens']
 assert new_calls==83548 and new_tokens==46998386
 result=dict(complete=True,models=results,action_models=action_models,deepseek_action=s['analyses'],cost=dict(a6_valid_new_requests=new_calls,a6_valid_new_measured_tokens=new_tokens,unknown_valid_usage=0,deepseek_valid_new_requests=16717,deepseek_valid_measured_tokens=9291352,excluded_tokenizer_batch_requests=16525,excluded_tokenizer_batch_measured_tokens=10764416,excluded_tokenizer_batch_unknown_usage=4,all_a6_recorded_requests=100073,all_a6_measured_tokens=57762802,shared_humaneval_upstream_counted_once_in_A4=dict(requests=1968,tokens=1205804)),no_intervals=True,model_calls_during_analysis=0)
 target=ROOT/'ccfa-workfiles/manuscript/icse-oracle/build/a6_results.json';target.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':True,'models':len(results),'action_responses':len(ar),'new_cost':result['cost']}))
 return result
if __name__=='__main__':main()
