"""Render the matched configuration comparison from independently replayed fields."""
from judge_repair_analysis import main
def render(table,evidence,num):
    data=main();source='a7_cross_source/judge_repair/publication/data.json'
    cells=[('qwen',m) for m in ['qwen9','qwen27','qwen35','gemma','deepseek']]+[('gemma',m) for m in ['qwen9','gemma']]
    names=dict(qwen='Qwen9B',qwen9='Qwen9B',qwen27='Qwen27B',qwen35='Qwen35B',gemma='Gemma',deepseek='DeepSeek')
    rows=[];decomp=[];formation=[];transitions=[]
    def rate(g,era):return f'{g[era]["delta_pp"]:+.2f}'
    def slash(v):return '/'.join(str(x) for x in v)
    for s,m in cells:
        gs=data['cells'][s+'/'+m];c=gs['conflicts'];g=gs['guards'];a=gs['available_attempts'];f=gs['formed_originals']
        rows.append([names[s],names[m],int(c['new']['n']),int(g['new']['n']),rate(c,'old')+'/'+rate(c,'new'),rate(g,'old')+'/'+rate(g,'new'),rate(gs['guards_joint_old_new_available'],'new')])
        for scope,label in [('conflicts','Conflict'),('guards','Guard')]:
            b=gs[scope]['new'];d=b['delta'];td=b['task_direction']
            decomp.append([names[s],names[m],label]+[f'{d[k]:+.2f}' for k in ['recovered','regressed','correct_removed_technical','correct_removed_defer']]+[slash(b['seed_delta_u']),slash([td[k] for k in ['improved','worsened','tied']])])
        failure=lambda era:slash([int(3*a[era]['means'][arm]['technical_failure']) for arm in ['visible','hidden']])
        formation.append([names[s],names[m],int(a['new']['n']),rate(f,'old')+'/'+rate(f,'new'),failure('old'),failure('new'),slash([num(gs['all_fixed_slots']['new']['means'][arm]['new_correct_from_unformed_original']) for arm in ['visible','hidden']])])
        def count(pred):
            return slash([sum(t['count'] for t in a['transitions'][arm] if pred(t['old'],t['new'])) for arm in ['visible','hidden']])
        technical={'length','wire_or_schema','invalid_literal','contract'}
        transitions.append([names[s],names[m],count(lambda o,n:o in technical and n=='correct'),count(lambda o,n:o=='correct' and n in technical),count(lambda o,n:o=='correct' and n=='incorrect'),count(lambda o,n:o=='correct' and n=='correct')])
    specs=[('judge_configuration_visibility','tab:judge_configuration',
        r'Matched judgment-configuration comparison on the same 40 HumanEval tasks and corrected code pools. Each old/new entry is hidden minus visible useful retention in percentage points. Conflict/guard $n$ counts frozen inputs. The new service permits JSON whitespace; original assertions, full request bodies, seeds and output caps are held fixed. Joint is the new guard contrast restricted to input--seed pairs technically available in both arms under both configurations; it has a separate conditional denominator (Appendix~\ref{app:judge_configuration}).',
        ['Source','Judge','$n_C$','$n_G$',r'Conflict old/new',r'Guard old/new',r'Joint guard'],rows),
        ('judge_configuration_decomposition','tab:judge_config_decomposition',
        r'Repaired-configuration accounting in mean counts, hidden minus visible. $D_F$ is correct removal through technical failure; $D_S$ is semantic deferral. Every row satisfies $\Delta U=\Delta R-\Delta H-\Delta D_F-\Delta D_S$ before rounding. Seeds are 47001/47002/47003; task directions combine inputs and seeds within each task. All 21 guard cell--seed contrasts are negative.',
        ['Source','Judge','Cohort',r'$\Delta R$',r'$\Delta H$',r'$\Delta D_F$',r'$\Delta D_S$',r'$\Delta U$ by seed','Tasks +/--/='],decomp),
        ('judge_configuration_formation','tab:judge_config_formation',
        r'Formation and technical outcomes on all available original inputs. $n_A$ is inputs with an original available for paired inference. Formed $\Delta$ is hidden minus visible retention in percentage points on the frozen formed-original cohort, old/new. $F$ counts all technical failures over three seeds, visible/hidden, including literal and contract failures. New $N$ is the mean newly correct output from initially unformed originals, visible/hidden. The complete fixed frame remains 320 slots per cell; missing original dependencies stay unstarted.',
        ['Source','Judge','$n_A$',r'Formed $\Delta$ old/new',r'Old $F$ V/H',r'New $F$ V/H',r'New $N$ V/H'],formation),
        ('judge_configuration_transitions','tab:judge_config_transitions',
        r'Matched old-to-new response transitions over the three seeds, visible/hidden. $T$ includes response-level, output-cap, literal and contract failures; $C$ is a reference-consistent retained assertion and $W$ a reference-inconsistent retained assertion. These selected transitions are descriptive, not a complete transition matrix. The portable projection retains the complete matrix. Responses shared across source cells remain shared observations.',
        ['Source','Judge',r'$T\to C$',r'$C\to T$',r'$C\to W$',r'$C\to C$'],transitions)]
    for name,label,caption,header,rs in specs:
        evidence[name]=dict(source=source,rows=rs);table(name,caption,label,header,rs,wide=True)
