"""Portable aggregation of paired historical/repaired judgment outcomes; no intervals."""
from collections import Counter, defaultdict
import hashlib, json, statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
SEEDS=[47001,47002,47003]
ARMS=['visible','hidden']
FIELDS=['initial_correct','initial_wrong','correct_retained','recovered','regressed','removed_correct',
        'new_correct_from_unformed_original','semantic_defer','technical_failure','dependent_not_started',
        'retained','correct_removed_technical','correct_removed_defer','unadjudicable_final']
def block(rows):
    byseed={str(s):{a:{'n':len(rs),**{f:sum(bool(r[f]) for r in rs) for f in FIELDS}}
                     for a in ARMS for rs in [[r for r in rows if r['seed']==s and r['arm']==a]]} for s in SEEDS}
    means={a:{f:statistics.mean(byseed[str(s)][a][f] for s in SEEDS) for f in ['n',*FIELDS]} for a in ARMS}
    for a,m in means.items():
        assert abs(m['correct_retained']-(m['initial_correct']+m['recovered']-m['regressed']-m['removed_correct']+m['new_correct_from_unformed_original']))<1e-8
        assert abs(m['removed_correct']-m['correct_removed_technical']-m['correct_removed_defer'])<1e-8
    delta={f:means['hidden'][f]-means['visible'][f] for f in FIELDS}
    tasks=defaultdict(lambda:defaultdict(int))
    for r in rows:
        tasks[r['task_id']][r['arm']]+=r['correct_retained']
        tasks[r['task_id']][r['arm']+'_n']+=1
    task_values={t:dict(delta_u=v['hidden']-v['visible'],n=v['visible_n'],delta_pp=100*(v['hidden']-v['visible'])/v['visible_n']) for t,v in tasks.items() if v['visible_n']}
    pp=100*delta['correct_retained']/means['visible']['n'] if means['visible']['n'] else None
    return dict(n=means['visible']['n'],cases=len({r['case_id'] for r in rows}),tasks=len(tasks),means=means,delta=delta,delta_pp=pp,
        per_seed=byseed,seed_delta_u=[byseed[str(s)]['hidden']['correct_retained']-byseed[str(s)]['visible']['correct_retained'] for s in SEEDS],
        task_direction={name:sum(pred(v['delta_u']) for v in task_values.values()) for name,pred in [('improved',lambda x:x>0),('worsened',lambda x:x<0),('tied',lambda x:x==0)]},
        task_macro_delta_pp=statistics.mean(v['delta_pp'] for v in task_values.values()) if task_values else None,
        task_values=task_values,categories={a:dict(Counter(r['category'] for r in rows if r['arm']==a)) for a in ARMS})
def key(r):return (r['case_id'],r['seed'],r['arm'])
def category_transition(rows):
    old={key(r):r for r in rows['old']};new={key(r):r for r in rows['new']};assert old.keys()==new.keys()
    return {a:[dict(old=o,new=n,count=c) for (o,n),c in sorted(Counter((old[k]['outcome'],new[k]['outcome']) for k in old if k[2]==a).items())] for a in ARMS}
def reaggregate(data):
    labels=data['labels'];cells={}
    common={k for k in labels['qwen'] if all(labels[s][k]['before'] is not None and labels[s][k]['reference_adjudicable'] for s in labels)}
    common_c={k for k in common if all(labels[s][k]['any_conflict'] for s in labels)}
    common_g={k for k in common if all(labels[s][k]['subgroup']=='guard' for s in labels)}
    for cell,eras in data['evaluations'].items():
        assert set(eras)=={'old','new'}
        for era,rows in eras.items():
            assert len(rows)==1920 and len({key(r) for r in rows})==1920
            assert {r['task_id'] for r in rows}==set(data['selected_task_ids'])
        paired={}
        for era,rows in eras.items():
            p=defaultdict(list)
            for r in rows:p[(r['case_id'],r['seed'])].append(r)
            assert all(len(v)==2 for v in p.values())
            paired[era]={k for k,rs in p.items() if not any(r['technical_failure'] or r['dependent_not_started'] for r in rs)}
        joint=paired['old'] & paired['new']
        groups={'all_fixed_slots':lambda r:True,'available_attempts':lambda r:not r['dependent_not_started'],
                'formed_originals':lambda r:r['original_wellformed'] and r['reference_adjudicable'],
                'conflicts':lambda r:r['any_conflict'] and r['reference_adjudicable'],
                'guards':lambda r:r['subgroup']=='guard' and r['reference_adjudicable'],
                'common_formed':lambda r:r['case_id'] in common,'common_conflicts':lambda r:r['case_id'] in common_c,
                'common_guards':lambda r:r['case_id'] in common_g,
                'guards_joint_old_new_available':lambda r:r['subgroup']=='guard' and (r['case_id'],r['seed']) in joint,
                'conflicts_joint_old_new_available':lambda r:r['any_conflict'] and (r['case_id'],r['seed']) in joint,
                'conflicts_sensitive_excluded':lambda r:r['any_conflict'] and r['task_id'] not in {'HumanEval/14','HumanEval/57','HumanEval/90'}}
        out={}
        for group,pred in groups.items():
            rs={era:[r for r in rows if pred(r)] for era,rows in eras.items()}
            g={era:block(rows) for era,rows in rs.items()}
            assert g['old']['n']==g['new']['n']
            g['new_minus_old']={a:{f:g['new']['means'][a][f]-g['old']['means'][a][f] for f in FIELDS} for a in ARMS}
            g['visibility_delta_difference_pp']=g['new']['delta_pp']-g['old']['delta_pp'] if g['new']['delta_pp'] is not None else None
            g['transitions']=category_transition(rs);out[group]=g
        cells[cell]=out
    return dict(passed=True,cells=cells,common_cohorts=dict(formed=len(common),conflicts=len(common_c),guards=len(common_g)),
        formal_requests=9636,logical_source_judge_responses=12126,within_new_config_reuse=2490,
        cost=data['cost'],protocol=data['protocol'],model_calls=0,no_confidence_intervals=True)
def main():
    p=ROOT/'a7_cross_source/judge_repair/publication/data.json';data=json.loads(p.read_text())
    out=reaggregate(data);out['source_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
    dest=ROOT/'ccfa-workfiles/manuscript/icse-oracle/build/judge_repair_results.json';dest.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    return out
if __name__=='__main__':
    out=main();print(json.dumps(dict(passed=out['passed'],formal_requests=out['formal_requests'],model_calls=0)))
