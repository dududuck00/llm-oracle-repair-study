"""Analyze frozen A2 first responses, without inference or external packages.

The primary bound policy is the complete status-first, KEEP-priority rule
explicitly written in the A2 prompt. Entailment and finite-domain detection
are evaluated separately. Technical failures stay in attempted denominators;
unexecuted planned jobs, if any, are never scored as technical DEFER.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MODELS = ("qwen35_9b", "llama31_8b")
SEEDS = (46001, 46002)
ACTIONS = ("KEEP", "REPAIR", "DEFER")
POLICIES = ("raw", "bound", "literal", "KEEP", "DEFER")
UNIVERSE = tuple(range(-128, 129))


def canon(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def jsonl(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def accepts(assertion, value):
    assert assertion["kind"] in ("equals", "one_of")
    values = assertion["values"]
    assert values and len(values) == len(set(values))
    assert all(type(v) is int and v in UNIVERSE for v in values)
    if assertion["kind"] == "equals":
        assert len(values) == 1
    return type(value) is int and value in values


def bound_action(prediction, valid, status_first=True):
    if not valid or status_first and prediction.get("requirement_status") != "known":
        return "DEFER"
    if prediction.get("original_validity") == "supported":
        return "KEEP"
    if prediction.get("proposal_validity") == "supported":
        return "REPAIR"
    return "DEFER"


def chosen_action(row, policy):
    return policy if policy in ACTIONS else row[policy + "_action"]


def outcome(row, action):
    gold = row["gold"]
    original_ok = gold["original"] == "supported"
    replacement_ok = gold["proposal"] == "supported"
    submitted = action != "DEFER"
    selected_ok = original_ok if action == "KEEP" else replacement_ok
    useful = submitted and selected_ok
    acceptance = gold["original_acceptance"] if action == "KEEP" else gold["replacement_acceptance"]
    truth = set(gold["allowed_outputs"])
    illegal = set(UNIVERSE) - truth
    selected_acceptance = set(acceptance)
    return dict(total=1, original_correct=int(original_ok), original_wrong=int(not original_ok),
                repairable=int(not original_ok and replacement_ok), submitted=int(submitted), useful=int(useful),
                recovery=int(not original_ok and useful),
                regression=int(original_ok and action == "REPAIR" and not replacement_ok),
                correct_discard=int(original_ok and action == "DEFER"),
                correct_technical_discard=int(original_ok and action == "DEFER" and not row["valid"]),
                wrong_assertion_submitted=int(submitted and not selected_ok),
                wrong_original_kept=int(not original_ok and action == "KEEP"),
                keep=int(action == "KEEP"), repair=int(action == "REPAIR"), defer=int(action == "DEFER"),
                exact_finite_oracle_submitted=int(submitted and selected_acceptance == truth),
                illegal_output_acceptances=int(submitted) * len(selected_acceptance & illegal),
                illegal_output_rejections=int(submitted) * len(illegal - selected_acceptance))


def metrics(rows, policy):
    zero = outcome(dict(gold=dict(original="violated", proposal="violated", allowed_outputs=[0],
                                 original_acceptance=[1], replacement_acceptance=[2]), valid=False), "DEFER")
    result = Counter({name: 0 for name in zero})
    for row in rows:
        result.update(outcome(row, chosen_action(row, policy)))
    assert result["total"] == result["keep"] + result["repair"] + result["defer"]
    assert result["useful"] == result["original_correct"] + result["recovery"] - result["regression"] - result["correct_discard"]
    assert result["submitted"] == result["useful"] + result["wrong_assertion_submitted"]
    assert result["recovery"] <= result["repairable"]
    return dict(result)


def ratio(a, b):
    return a / b if b else None


def distribution(values):
    values = sorted(values)
    if not values:
        return dict(n=0, minimum=None, median=None, maximum=None, mean=None)
    n = len(values)
    return dict(n=n, minimum=values[0], median=(values[(n - 1) // 2] + values[n // 2]) / 2,
                maximum=values[-1], mean=sum(values) / n)


def diagnostics(rows):
    names = ("attempts", "valid", "technical_failure", "rule_mismatch", "literal_rule_mismatch",
             "bound_literal_policies_differ", "original_supported_predictions", "original_supported_but_raw_repair",
             "original_judgment_correct", "proposal_judgment_correct", "both_assertion_judgments_correct",
             "requirement_status_correct", "global_judgment_correct", "decision_fields_correct",
             "all_report_fields_correct", "rule_mismatch_when_decision_fields_correct",
             "rule_mismatch_when_all_report_fields_correct", "harm_when_assertion_fields_correct",
             "harm_when_decision_fields_correct", "both_assertions_predicted_supported",
             "legal_singleton_targets", "legal_singleton_targets_available", "legal_singleton_false_support",
             "reason_first", "order_matches", "request_length_finish", "request_other_nonstop_finish",
             "usage_unmeasured", "prompt_token_mismatch", "measured_prompt_tokens",
             "measured_completion_tokens", "measured_total_tokens")
    counts = Counter({name: 0 for name in names})
    errors, finishes = Counter(), Counter()
    lengths = []
    for row in rows:
        q, g, valid = row["prediction"], row["gold"], row["valid"]
        counts["attempts"] += 1
        counts["valid"] += valid
        counts["technical_failure"] += not valid
        mismatch = valid and row["raw_action"] != row["bound_action"]
        counts["rule_mismatch"] += mismatch
        counts["literal_rule_mismatch"] += valid and row["raw_action"] != row["literal_action"]
        counts["bound_literal_policies_differ"] += valid and row["bound_action"] != row["literal_action"]
        counts["original_supported_predictions"] += valid and q.get("original_validity") == "supported"
        counts["original_supported_but_raw_repair"] += valid and q.get("original_validity") == "supported" and row["raw_action"] == "REPAIR"
        original_ok = valid and q.get("original_validity") == g["original"]
        proposal_ok = valid and q.get("proposal_validity") == g["proposal"]
        status_ok = valid and q.get("requirement_status") == g["status"]
        global_ok = valid and q.get("implementation_global") == g["global_truth"]
        both = original_ok and proposal_ok
        decision = both and status_ok
        all_report = decision and global_ok
        counts["original_judgment_correct"] += original_ok
        counts["proposal_judgment_correct"] += proposal_ok
        counts["both_assertion_judgments_correct"] += both
        counts["requirement_status_correct"] += status_ok
        counts["global_judgment_correct"] += global_ok
        counts["decision_fields_correct"] += decision
        counts["all_report_fields_correct"] += all_report
        counts["rule_mismatch_when_decision_fields_correct"] += decision and mismatch
        counts["rule_mismatch_when_all_report_fields_correct"] += all_report and mismatch
        harm = outcome(row, row["raw_action"])["regression"]
        counts["harm_when_assertion_fields_correct"] += both and harm
        counts["harm_when_decision_fields_correct"] += decision and harm
        counts["both_assertions_predicted_supported"] += valid and q.get("original_validity") == q.get("proposal_validity") == "supported"
        for key, field in (("original_legal_singleton_not_entailed", "original_validity"),
                           ("proposal_legal_singleton_not_entailed", "proposal_validity")):
            target = bool(g.get(key))
            counts["legal_singleton_targets"] += target
            counts["legal_singleton_targets_available"] += target and valid
            counts["legal_singleton_false_support"] += target and valid and q.get(field) == "supported"
        counts["reason_first"] += row["reason_first"]
        counts["order_matches"] += row["order_matches"]
        counts["request_length_finish"] += row["finish_reason"] == "length"
        counts["request_other_nonstop_finish"] += row["finish_reason"] not in ("stop", "length", None)
        finishes[str(row["finish_reason"])] += 1
        if row["reason_length"] is not None:
            lengths.append(row["reason_length"])
        if row["error"]:
            errors[row["error"].split(":", 1)[0]] += 1
        usage = row["usage"]
        counts["usage_unmeasured"] += usage.get("total_tokens") is None
        for part in ("prompt", "completion", "total"):
            counts["measured_" + part + "_tokens"] += usage.get(part + "_tokens") or 0
        predicted = row["predicted_prompt_tokens"]
        counts["prompt_token_mismatch"] += predicted is not None and usage.get("prompt_tokens") is not None and predicted != usage["prompt_tokens"]
    result = dict(counts)
    result.update(rule_mismatch_rate_valid=ratio(counts["rule_mismatch"], counts["valid"]),
                  rule_mismatch_per_attempt=ratio(counts["rule_mismatch"], counts["attempts"]),
                  rule_mismatch_rate_given_correct_decision_fields=ratio(counts["rule_mismatch_when_decision_fields_correct"], counts["decision_fields_correct"]),
                  legal_singleton_false_support_rate_available=ratio(counts["legal_singleton_false_support"], counts["legal_singleton_targets_available"]),
                  reason_lengths=distribution(lengths), finish_reasons=dict(finishes), error_types=dict(errors))
    return result


def decompose(rows, policy):
    keys = ("harm_prevented_to_keep", "harm_prevented_to_defer", "harm_remaining", "harm_introduced",
            "recovery_preserved", "recovery_lost_to_keep", "recovery_lost_to_defer",
            "recovery_gained_from_keep", "recovery_gained_from_defer", "correct_defer_to_keep", "correct_keep_to_defer")
    counts = Counter({k: 0 for k in keys})
    transitions = {a: {b: 0 for b in ACTIONS} for a in ACTIONS}
    for row in rows:
        a, b = row["raw_action"], row[policy + "_action"]
        raw, bound = outcome(row, a), outcome(row, b)
        transitions[a][b] += 1
        if raw["regression"]:
            counts["harm_prevented_to_keep" if b == "KEEP" else "harm_prevented_to_defer" if b == "DEFER" else "harm_remaining"] += 1
        counts["harm_introduced"] += bound["regression"] and not raw["regression"]
        if raw["recovery"]:
            counts["recovery_preserved" if bound["recovery"] else "recovery_lost_to_" + b.lower()] += 1
        elif bound["recovery"]:
            counts["recovery_gained_from_" + a.lower()] += 1
        if raw["original_correct"]:
            counts["correct_defer_to_keep"] += a == "DEFER" and b == "KEEP"
            counts["correct_keep_to_defer"] += a == "KEEP" and b == "DEFER"
    raw, bound = metrics(rows, "raw"), metrics(rows, policy)
    counts["harm_net_reduction"] = raw["regression"] - bound["regression"]
    counts["recovery_lost"] = counts["recovery_lost_to_keep"] + counts["recovery_lost_to_defer"]
    counts["recovery_gained"] = counts["recovery_gained_from_keep"] + counts["recovery_gained_from_defer"]
    counts["recovery_net_change"] = bound["recovery"] - raw["recovery"]
    counts["useful_net_change"] = bound["useful"] - raw["useful"]
    assert counts["harm_net_reduction"] == counts["harm_prevented_to_keep"] + counts["harm_prevented_to_defer"] - counts["harm_introduced"]
    assert counts["recovery_net_change"] == counts["recovery_gained"] - counts["recovery_lost"]
    assert counts["useful_net_change"] == counts["recovery_net_change"] + counts["harm_net_reduction"] - (bound["correct_discard"] - raw["correct_discard"])
    return dict(counts=dict(counts), transitions=transitions)


def summarize(rows):
    return dict(diagnostics=diagnostics(rows), policies={p: metrics(rows, p) for p in POLICIES},
                binding={p: decompose(rows, p) for p in ("bound", "literal")})


def scopes(row):
    g = row["gold"]
    yield "all"
    yield "conflict" if row["conflict"] else "guard"
    yield "regime_" + g["semantic_regime"]
    yield "family_" + g["family"]
    yield "pair_class_" + g["pair_class"]
    yield "seed_" + str(row["seed"])
    yield "original_correct" if g["original"] == "supported" else "original_wrong"
    yield "repairable" if g["original"] != "supported" and g["proposal"] == "supported" else "not_repairable"
    if row["valid"]:
        q = row["prediction"]
        decision = q.get("requirement_status") == g["status"] and q.get("original_validity") == g["original"] and q.get("proposal_validity") == g["proposal"]
        yield "decision_fields_correct" if decision else "decision_fields_incorrect"
    else:
        yield "technical_failure"


def paired(rows):
    lookup = {(row["model_id"], row["panel"]): row for row in rows}
    ids = sorted({row["panel"] for row in rows})
    common_attempted = [pid for pid in ids if all((m, pid) in lookup for m in MODELS)]
    states = ("consistent", "inconsistent", "technical_failure", "unexecuted")
    matrix = {a: {b: 0 for b in states} for a in states}
    def state(row):
        if row is None:
            return "unexecuted"
        return "technical_failure" if not row["valid"] else "consistent" if row["raw_action"] == row["bound_action"] else "inconsistent"
    for pid in ids:
        matrix[state(lookup.get((MODELS[0], pid)))][state(lookup.get((MODELS[1], pid)))] += 1
    common_valid = [pid for pid in common_attempted if all(lookup[(m, pid)]["valid"] for m in MODELS)]
    return dict(direction=dict(rows=MODELS[0], columns=MODELS[1]), attempted_panel_union=len(ids),
                both_models_attempted_pairs=len(common_attempted), common_valid_pairs=len(common_valid),
                consistency_state_transitions=matrix,
                common_valid={m: summarize([lookup[(m, pid)] for pid in common_valid]) for m in MODELS})


def pct(value):
    return "—" if value is None else f"{100 * value:.1f}%"


def result_tables(out):
    lines = ["# A2完整结果", "", "主政策bound逐字落实A2提示中的状态优先及KEEP优先规则；literal不检查状态，作为第二政策。", "",
             "## 技术完成、语义字段与动作", "", "|模型|已尝试/计划|有效|动作规则违例|决策字段全对|全对时仍违例|原supported却REPAIR|合法singleton误判supported|length|tokens|",
             "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for model in MODELS:
        d = out["models"][model]["all"]["diagnostics"]
        planned = out["execution"]["by_model"][model]["planned_formal"]
        lines.append(f'|{model}|{d["attempts"]}/{planned}|{d["valid"]}|{d["rule_mismatch"]}|{d["decision_fields_correct"]}|{d["rule_mismatch_when_decision_fields_correct"]}|{d["original_supported_but_raw_repair"]}|{d["legal_singleton_false_support"]}/{d["legal_singleton_targets_available"]}|{d["request_length_finish"]}|{d["measured_total_tokens"]}|')
    lines += ["", "违例只在有效响应上判定；技术失败不算一致性成功。合法singleton分母为有效响应中具备该诊断的断言目标数。未执行请求单列，不当DEFER计分。", "",
              "## 合同蕴涵下的修复结果", "", "|范围|模型|政策|恢复|误修|正确丢弃|其中技术失败|有用(entailed)|有限域精确oracle|", "|---|---|---|---:|---:|---:|---:|---:|---:|"]
    for scope in ("all", "conflict", "guard"):
        for model in MODELS:
            for policy in ("raw", "bound", "literal", "KEEP", "DEFER"):
                m = out["models"][model][scope]["policies"][policy]
                lines.append(f'|{scope}|{model}|{policy}|{m["recovery"]}|{m["regression"]}|{m["correct_discard"]}|{m["correct_technical_discard"]}|{m["useful"]}|{m["exact_finite_oracle_submitted"]}|')
    lines += ["", "有用表示提交的断言被需求蕴涵；有限域精确oracle另要求接受集合恰好等于允许输出集合。非法输出接受/拒绝量在summary.json中另列，不以蕴涵自动宣称检错完备。", "",
              "## 绑定保护与恢复转移", "", "|范围|模型|政策|误修→KEEP|误修→DEFER|新增误修|恢复丢失→KEEP|恢复丢失→DEFER|新增恢复|恢复净变化|", "|---|---|---|---:|---:|---:|---:|---:|---:|---:|"]
    for scope in ("all", "conflict", "guard"):
        for model in MODELS:
            for policy in ("bound", "literal"):
                c = out["models"][model][scope]["binding"][policy]["counts"]
                lines.append(f'|{scope}|{model}|{policy}|{c["harm_prevented_to_keep"]}|{c["harm_prevented_to_defer"]}|{c["harm_introduced"]}|{c["recovery_lost_to_keep"]}|{c["recovery_lost_to_defer"]}|{c["recovery_gained"]}|{c["recovery_net_change"]:+d}|')
    lines += ["", "## 合法值与断言蕴涵", "", "|模型|语义范围|有效|原判断正确|候选判断正确|两判断均正确|动作规则违例|", "|---|---|---:|---:|---:|---:|---:|"]
    for model in MODELS:
        for scope in out["design"]["regime_scopes"]:
            d = out["models"][model][scope]["diagnostics"]
            lines.append(f'|{model}|{scope}|{d["valid"]}|{d["original_judgment_correct"]}|{d["proposal_judgment_correct"]}|{d["both_assertion_judgments_correct"]}|{d["rule_mismatch"]}|')
    lines += ["", "逐家族、seed、条件全对、两模型共同成功和完整成本见summary.json，逐响应判断及转移见evaluations.jsonl。只解释本次共同有限合同面板，不以seed或配置重复计算总体显著性。"]
    return "\n".join(lines) + "\n"


def analysis_text(out):
    lines = ["# A2：新有限合同与不同家族模型确认", "", "## 评价设计", "",
             "12个有限操作家族（唯一结果与明确多合法结果各6族），每族两个输入、三个冲突断言对状态及一个原正确守卫，两个seed。两模型共用192个带seed面板，计划384正式＋8工程请求。主提示固定当前输入优先，完整状态优先/KEEP优先规则明示；理由没有字段字符上限，整体输出额度2048 tokens。", "",
             "需求蕴涵定义为每个合法输出均满足断言。某值合法不足以支持只接受该值的singleton断言。作者有限合同由独立程序复算；自然语言总体正确率不属于该评分。", "",
             "## 三层结果", ""]
    for model in MODELS:
        d = out["models"][model]["all"]["diagnostics"]
        raw, bound = (out["models"][model]["all"]["policies"][p] for p in ("raw", "bound"))
        c = out["models"][model]["all"]["binding"]["bound"]["counts"]
        lines += [f'- {model}：正式尝试{d["attempts"]}，技术有效{d["valid"]}，失败{d["technical_failure"]}（length={d["request_length_finish"]}）。有效响应动作违例{d["rule_mismatch"]}，比例{pct(d["rule_mismatch_rate_valid"])}。',
                  f'  决策相关字段均符合合同{d["decision_fields_correct"]}份，其中动作仍违例{d["rule_mismatch_when_decision_fields_correct"]}（条件比例{pct(d["rule_mismatch_rate_given_correct_decision_fields"])}）；原supported却REPAIR={d["original_supported_but_raw_repair"]}。两个断言字段正确时的危险误修={d["harm_when_assertion_fields_correct"]}。',
                  f'  自由动作→主绑定：误修{raw["regression"]}→{bound["regression"]}，减少路径KEEP{c["harm_prevented_to_keep"]}/DEFER{c["harm_prevented_to_defer"]}；恢复{raw["recovery"]}→{bound["recovery"]}，丢失{c["recovery_lost"]}、新增{c["recovery_gained"]}；正确丢弃{raw["correct_discard"]}→{bound["correct_discard"]}，有用{raw["useful"]}→{bound["useful"]}。']
        for scope in ("conflict", "guard"):
            a, b = (out["models"][model][scope]["policies"][p] for p in ("raw", "bound"))
            c = out["models"][model][scope]["binding"]["bound"]["counts"]
            lines.append(f'  {scope}：误修{a["regression"]}→{b["regression"]}；恢复{a["recovery"]}→{b["recovery"]}（丢失{c["recovery_lost"]}、新增{c["recovery_gained"]}）。')
    lines += ["", "## 共同可用配对与字段接口", "",
              f'两模型均已尝试的面板对{out["paired"]["both_models_attempted_pairs"]}，均技术有效{out["paired"]["common_valid_pairs"]}。共同有效子集用于敏感性分析，不取代全部尝试；技术失败在配对状态矩阵中单列。']
    for model in MODELS:
        d = out["paired"]["common_valid"][model]["diagnostics"]
        full = out["models"][model]["all"]["diagnostics"]
        lines.append(f'- {model}共同有效子集：动作违例{d["rule_mismatch"]}/{d["valid"]}；全尝试理由顺序匹配{full["order_matches"]}/{full["attempts"]}；正式实际tokens={full["measured_total_tokens"]}，usage缺失={full["usage_unmeasured"]}。')
    cost = out["cost"]["all"]
    lines += ["", "## 结论读取", "",
              "动作规则一致性是声明字段和最终动作的可程序核查关系；全部决策字段正确子集进一步定位判断之后的动作失配。确定性绑定的规则一致性按构造成立，其语义保护和恢复结果按本轮合同实测。保护须分KEEP与DEFER，净恢复须与毛损失、新增恢复一并读取。", "",
              "A2使用新任务和完整明确规则，是新协议下的确认。跨模型比较来自A2内部共同面板；不将A1→A2变化归因于单一提示、任务或模型因素。12家族及两个seed不支持LLMs总体发生率推断，不报告基于重复配置的总体显著性。", "",
              f'全部已归档首响应{cost["requests"]}次，实际计量{cost["measured_tokens"]} tokens，未计量{cost["unmeasured"]}次；失败{cost["errors"]}次完整保留。正式是否完整完成：{out["execution"]["complete"]}。', "",
              "完整表见RESULTS.md，逐家族与配对见summary.json，逐事件见evaluations.jsonl，独立合同复算和源哈希见verification.json。"]
    return "\n".join(lines) + "\n"


def validate_public_gold(panel, gold):
    c = panel["content"]
    assert gold["status"] == "known"
    assert gold["family"] == panel["family"]
    assert gold["semantic_regime"] == panel["semantic_regime"]
    assert gold["pair_class"] == panel["pair_class"]
    truth = set(gold["allowed_outputs"])
    assert truth and truth <= set(UNIVERSE)
    for field, content_key, acceptance_key, singleton_key in (
        ("original", "original_assertion", "original_acceptance", "original_legal_singleton_not_entailed"),
        ("proposal", "replacement_assertion", "replacement_acceptance", "proposal_legal_singleton_not_entailed")):
        acceptance = {v for v in UNIVERSE if accepts(c[content_key], v)}
        assert acceptance == set(gold[acceptance_key])
        assert gold[field] == ("supported" if truth <= acceptance else "violated")
        singleton = len(truth) > 1 and len(acceptance) == 1 and acceptance <= truth
        assert bool(gold.get(singleton_key)) == singleton
    conflict = not accepts(c["original_assertion"], c["observed_output"])
    assert conflict == gold["conflict"]
    assert (panel["scope"] == "conflict") == conflict
    assert gold["current_actual_correct"] == (c["observed_output"] in truth)
    gold_action = "KEEP" if gold["original"] == "supported" else "REPAIR" if gold["proposal"] == "supported" else "DEFER"
    assert gold["gold_action"] == gold_action


def validate_request(job, record):
    req = record.get("request")
    assert req and record.get("request_hash"), "Actual first request and its hash are mandatory"
    assert sha_bytes(canon(req).encode()) == record["request_hash"]
    assert req["model"] == job["served_model"]
    assert record["model_id"] == job["model_id"]
    assert req["messages"] == [{"role": "system", "content": job["system"]}, {"role": "user", "content": canon(job["content"])}]
    assert req["temperature"] == 0.2 and req["seed"] == job["seed"] and req["max_tokens"] == job["cap"] == 2048
    assert req["chat_template_kwargs"] == {"enable_thinking": False}
    assert req["structured_outputs"] == {"grammar": job["grammar"]}
    return req


def sha_bytes(value):
    return hashlib.sha256(value).hexdigest()


def validate_success(job, record, prediction):
    props = job["schema"]["properties"]
    assert set(prediction) == set(props)
    for key, specification in props.items():
        assert isinstance(prediction[key], str)
        if "enum" in specification:
            assert prediction[key] in specification["enum"]
    assert prediction["action"] in ACTIONS
    choice = record["response"]["choices"][0]
    assert choice["finish_reason"] == "stop"
    actual = json.loads(choice["message"]["content"])
    assert canon(actual) == canon(prediction)
    assert list(actual) == job["requested_order"] and list(actual)[0] == "reason"


def cost(records):
    return dict(requests=len(records), measured_tokens=sum((r.get("usage") or {}).get("total_tokens") or 0 for r in records),
                unmeasured=sum((r.get("usage") or {}).get("total_tokens") is None for r in records), errors=sum(bool(r.get("error")) for r in records))


def main(allow_incomplete=False):
    jobs, engineering = read(ROOT / "jobs.json"), read(ROOT / "engineering_jobs.json")
    panels_list = read(ROOT / "public/panels.json")
    panels = {p["id"]: p for p in panels_list}
    labels = read(ROOT / "private/labels.json")
    assert len(jobs) == 384 and len(engineering) == 8
    assert len(panels) == len(panels_list) == len(labels) == 192
    assert len({p["task"] for p in panels_list}) == 96
    assert len({p["family"] for p in panels_list}) == 12
    assert {p["seed"] for p in panels_list} == set(SEEDS)
    assert len({p["semantic_regime"] for p in panels_list}) == 2
    for p in panels_list:
        validate_public_gold(p, labels[p["id"]])
    logs = jsonl(ROOT / "calls.jsonl")
    calls = {r["id"]: r for r in logs}
    assert len(calls) == len(logs), "Duplicate first-response ID"
    required = {j["id"] for j in jobs + engineering}
    assert len(required) == 392
    assert set(calls) <= required, "Unregistered model calls must be settled explicitly"
    complete = required <= set(calls)
    if not allow_incomplete:
        assert complete, "Missing formal/engineering responses; --allow-incomplete preserves unexecuted counts"
    frozen = read(ROOT / "frozen.json")
    inputs = set(frozen["files"]) | {"frozen.json", "calls.jsonl"}
    before = {n: sha(ROOT / n) for n in sorted(inputs)}
    for n, expected in frozen["files"].items():
        assert before[n] == expected, n
    from contracts_check import verify_all
    independent_contract = verify_all(ROOT)
    assert independent_contract["passed"]
    matching = defaultdict(dict)
    for job in jobs:
        model, pid = job["model_id"], job["panel"]
        assert model in MODELS and pid in panels
        assert job["seed"] == panels[pid]["seed"]
        assert job["content"] == panels[pid]["content"]
        assert job["requested_order"] == list(job["schema"]["properties"])
        assert "maxLength" not in job["schema"]["properties"]["reason"]
        assert model not in matching[pid]
        matching[pid][model] = job
    assert len(matching) == 192
    for pair in matching.values():
        assert set(pair) == set(MODELS)
        a, b = (pair[m] for m in MODELS)
        for key in ("system", "content", "seed", "cap", "schema", "grammar", "requested_order"):
            assert a[key] == b[key], key
        if a["id"] in calls and b["id"] in calls:
            qa, qb = (dict(validate_request(j, calls[j["id"]])) for j in (a, b))
            assert qa.pop("model") != qb.pop("model")
            assert qa == qb, "Unexpected online cross-model prompt or parameter difference"
    for job in jobs + engineering:
        if job["id"] in calls:
            validate_request(job, calls[job["id"]])
    rows = []
    for job in jobs:
        if job["id"] not in calls:
            continue
        r = calls[job["id"]]
        q = r.get("parsed") or {}
        valid = not r.get("error") and bool(q)
        if valid:
            validate_success(job, r, q)
        choices = (r.get("response") or {}).get("choices") or []
        finish = choices[0].get("finish_reason") if choices else None
        content = (choices[0].get("message", {}).get("content") or "") if choices else ""
        order = None
        try:
            order = list(json.loads(content)) if content else None
        except (ValueError, TypeError):
            pass
        if r.get("response"):
            assert (r.get("usage") or {}) == (r["response"].get("usage") or {})
        gold = labels[job["panel"]]
        rows.append(dict(id=job["id"], model_id=job["model_id"], served_model=job["served_model"], panel=job["panel"],
                         task=panels[job["panel"]]["task"], seed=job["seed"], valid=valid, error=r.get("error"), prediction=q,
                         raw_action=q["action"] if valid else "DEFER", bound_action=bound_action(q, valid),
                         literal_action=bound_action(q, valid, False), gold=gold, conflict=gold["conflict"],
                         finish_reason=finish, reason_length=len(q["reason"]) if valid else r.get("reason_length"),
                         raw_key_order=order, reason_first=bool(order) and order[0] == "reason",
                         order_matches=order == job["requested_order"], usage=r.get("usage") or {},
                         predicted_prompt_tokens=r.get("predicted_prompt_tokens"), seconds=r.get("seconds"), request_hash=r["request_hash"]))
    scope_names = sorted({name for row in rows for name in scopes(row)} | {"all", "conflict", "guard"})
    regime_scopes = ["regime_" + s for s in sorted({p["semantic_regime"] for p in panels_list})]
    scope_names = sorted(set(scope_names) | set(regime_scopes))
    execution = dict(complete=complete, planned_formal=len(jobs), attempted_formal=len(rows), unexecuted_formal=len(jobs) - len(rows),
                     planned_engineering=len(engineering), attempted_engineering=sum(j["id"] in calls for j in engineering), by_model={})
    for model in MODELS:
        planned = [j for j in jobs if j["model_id"] == model]
        attempted = [r for r in rows if r["model_id"] == model]
        assert len(planned) == 192
        execution["by_model"][model] = dict(planned_formal=len(planned), attempted_formal=len(attempted), unexecuted_formal=len(planned) - len(attempted))
    out = dict(design=dict(base_configurations=96, panels_per_model=192, models=list(MODELS), seeds=list(SEEDS),
                           formal_requests=384, engineering_requests=8, independent_families=12,
                           semantic_regimes=sorted({p["semantic_regime"] for p in panels_list}), regime_scopes=regime_scopes,
                           output_token_cap=2048, output_universe=[-128, 128], primary_policy="explicit_status_first_keep_priority",
                           uncertainty="Fixed finite-contract counts; seeds/configurations are not independent semantic tasks; no population significance claim."),
               execution=execution, models={}, paired=paired(rows), cost={})
    for model in MODELS:
        selected = [r for r in rows if r["model_id"] == model]
        out["models"][model] = {name: summarize([r for r in selected if name in set(scopes(r))]) for name in scope_names}
        for policy in POLICIES:
            for metric, value in out["models"][model]["all"]["policies"][policy].items():
                partitions = [("conflict", "guard"), tuple(regime_scopes)]
                if complete:
                    partitions += [tuple("seed_" + str(s) for s in SEEDS), tuple("family_" + f for f in sorted({p["family"] for p in panels_list}))]
                for partition in partitions:
                    assert value == sum(out["models"][model][scope]["policies"][policy][metric] for scope in partition)
    out["cost"] = dict(all=cost(logs), formal=cost([calls[j["id"]] for j in jobs if j["id"] in calls]),
                       engineering=cost([calls[j["id"]] for j in engineering if j["id"] in calls]),
                       by_model={m: cost([r for r in logs if r.get("model_id") == m]) for m in MODELS})
    after = {n: sha(ROOT / n) for n in sorted(inputs)}
    assert before == after
    dump("summary.json", out)
    (ROOT / "evaluations.jsonl").write_text("".join(canon(r) + "\n" for r in rows), encoding="utf-8")
    (ROOT / "RESULTS.md").write_text(result_tables(out), encoding="utf-8")
    (ROOT / "ANALYSIS.md").write_text(analysis_text(out), encoding="utf-8")
    checks = dict(all_planned_first_responses_present=complete, no_duplicate_or_unregistered_first_responses=True,
                  frozen_hashes_match=True, expected_design_denominators=True, public_predicate_entailment_and_conflict_match=True,
                  independent_contract_program_agrees=True, common_panels_prompts_candidates_caps_and_grammar=True,
                  actual_online_requests_match_frozen_jobs=True, successful_json_and_real_field_order_verified=True,
                  invalid_responses_and_unexecuted_jobs_not_counted_as_consistent=True,
                  all_policy_metric_transition_and_partition_conservation=True, all_input_hashes_unchanged=True,
                  no_new_model_calls_by_analysis=True)
    verification = dict(passed=all(checks.values()), integrity_passed=all(v for k, v in checks.items() if k != "all_planned_first_responses_present"),
                        checks=checks, independent_contract=independent_contract, input_sha256_before=before, input_sha256_after=after,
                        output_sha256={n: sha(ROOT / n) for n in ("analyze.py", "summary.json", "evaluations.jsonl", "RESULTS.md", "ANALYSIS.md")})
    dump("verification.json", verification)
    print(canon(dict(passed=verification["passed"], complete=complete, execution=execution, cost=out["cost"],
                     primary={m: out["models"][m]["all"]["diagnostics"] for m in MODELS})))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--allow-incomplete", action="store_true", help="Report observed attempts and explicitly retain unexecuted planned denominators")
    main(parser.parse_args().allow_incomplete)
