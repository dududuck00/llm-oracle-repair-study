"""Verify supplement files and reproduce numerical tables offline."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

base = Path(__file__).resolve().parent
manifest = json.loads((base / "SHA256SUMS.json").read_text())
for name, expected in manifest.items():
    assert hashlib.sha256((base / name).read_bytes()).hexdigest() == expected, name
root = base / "oracle-conflict-research"
source = root / "ccfa-workfiles/manuscript/icse-oracle/source/build_tables.py"
subprocess.run([sys.executable, str(source)], cwd=root, check=True)
expected_tables = sorted((base / "history/expected/tables").glob("*.tex"))
assert len(expected_tables) == 32
for table in expected_tables:
    assert (root / "manuscript/tables" / table.name).read_bytes() == table.read_bytes(), table.name
assert (root / "ccfa-workfiles/manuscript/icse-oracle/build/a6_review_checks.json").read_bytes() == (base / "history/expected/a6_review_checks.json").read_bytes()
assert (root / "ccfa-workfiles/manuscript/icse-oracle/build/a7_results.json").read_bytes() == (base / "history/expected/a7_results.json").read_bytes()
for name in ["a7_correction_results.json", "interface_audit_results.json", "judge_repair_results.json"]:
    assert (root / "ccfa-workfiles/manuscript/icse-oracle/build" / name).read_bytes() == (base / "history/expected" / name).read_bytes()
publication = sorted((base / "expected/publication_tables").glob("*.tex"))
assert len(publication) == 12
for table in publication:
    assert (root / "manuscript/publication_tables" / table.name).read_bytes() == table.read_bytes(), table.name
assert (root / "ccfa-workfiles/manuscript/icse-oracle/build/icpc_results.json").read_bytes() == (base / "expected/icpc_results.json").read_bytes()
assert (root / "ccfa-workfiles/manuscript/icse-oracle/build/icpc_table_evidence.json").read_bytes() == (base / "expected/icpc_table_evidence.json").read_bytes()
print(json.dumps(dict(passed=True, verified_files=len(manifest), historical_numerical_tables=32, current_main_numerical_tables=5, current_supporting_numerical_tables=6, settings_tables=1, diagnostic_json_identical=True, diagnostic_json_files=6, new_model_calls=0)))
